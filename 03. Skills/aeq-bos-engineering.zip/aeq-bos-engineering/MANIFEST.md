# Manifest — ÆQ/BOS Engineering Cluster v0.1

**Package state:** `DRAFT_FOR_D_REVIEW`

| Artifact | Purpose | Status | SHA-256 |
|---|---|---|---|
| `SKILL.md` | Cluster behavior and boundaries | Draft | `81fea0ef9be674f7790ab7fa3cbc444b41b91626827538d3da38a22b19618d23` |
| `evals.json` | Fixed test scenarios | Draft | `020a36c56ae89f48b78932fc5575ffa1270970772a8923ee1ffe4c8ed8b2f9a5` |
| `grading.json` | Evaluation rubric | Draft | `4986bbc0c7a288dd923ec1e413db4ac4b5b78ffce16e31db5a68267e41590465` |
| `baseline-result.md` | Static-review / baseline status | Draft | `0bd16490b81329e4248a653202944a25da0d39ad0e2b02a3f9ca651607f6d27c` |
| `CHANGELOG.md` | Version changes | Draft | `024e305b1a9bc3ca800c6efab24ef0409b74cee9b1b511087a43d080c2e0b36d` |

## Evidence basis

- `GPT02_WORK_INTAKE_HANDOFF_20260910.md`: progressive hydration, no global
  rebuild, no inferred promotion, and explicit non-mutation state.
- `AEQ_MEM_PILAR_II_AEQUITAS_ROUTE_CMP_v0_1(1).md`: ÆQUITAS gate role, D final
  authority, and downstream consumers cannot self-validate.
- `AEQ_BOS_DOCUMENT_ARCHITECTURE_REGISTER_v0_1_20260914.xlsx`: current
  document-control vocabulary, preserved UNKNOWN, duplicate handling, and QA
  routing.

## Package gate

This package may be reviewed, tested, patched, or held. It is not installed,
validated, production-ready, canonical, deployed, merged, synchronized, or a
runtime authority. Any promotion requires explicit D approval supported by the
appropriate evidence.
