---
name: aeq-bos-engineering
description: 'Governed engineering workflows for ÆQUITAS (Pilar II) and BOS (Pilar I): architecture, review, diagnostics, documentation, readiness, incidents, planning, debt, and test design.'
---

# ÆQ/BOS Engineering Cluster

## Purpose

Translate D's intent into bounded engineering work for **BOS (Pilar I)** and
**ÆQUITAS (Pilar II)**. The cluster creates analyses, review artifacts,
checklists, test plans, and receiver-bound handoffs. It does not silently
change project state.

## Governing invariants

```text
SOURCE ≠ RECONSTRUCTION ≠ CLAIM ≠ VERIFIED ≠ CANON
ACCOUNT ≠ SESSION ≠ PROJECT ≠ CHAT ≠ ROLE ≠ AUTHORITY
```

- D/Aleja is the final decision authority.
- ÆQUITAS receives, registers, normalizes, contrasts, preserves conflicts,
  produces QA/receipts, and prepares a D gate. It does not self-promote.
- BOS provides foundational and operational documentation; it is not evidence
  that a downstream runtime, deployment, merge, or synchronization occurred.
- Start with the smallest relevant source set and expand only to resolve a
  concrete reference, contradiction, or missing evidence.
- Preserve variants, aliases, duplicates, raw logs, and `UNKNOWN`; never
  resolve a collision merely from naming, recency, or prose confidence.

## Universal workflow

1. Restate the requested outcome, scope, and authority boundary.
2. Inventory direct sources and label each as source, reconstruction, claim,
   verified evidence, or unknown.
3. Run the requested workflow below; use only evidence proportionate to the
   claim being made.
4. Return findings, uncertainty, artifacts created, and the smallest safe
   next action.
5. Stop for a `D_GATE_REQUIRED` if the request implies promotion, policy
   change, authority assignment, physical merge, synchronization, runtime
   activation, deployment, release, deletion, or another irreversible action.

## Commands

### `/architecture <decision or system>`

Use for an ADR, architecture review, or component design.

Required output:
- context and bounded decision surface;
- options with evidence status and authority impact;
- trade-offs across provenance, reversibility, maintainability, and cross-pillar boundaries;
- consequences and a D gate when a choice would promote or alter a governed route.

Add to every ADR: `source_set`, `claims_not_verified`, `non-goals`,
`reversibility`, and `promotion_effect: none | D_gate_required`.

### `/code-review <diff, PR, or file>`

Review code, scripts, templates, manifests, or automation proposals for
security, correctness, determinism, idempotency, provenance handling, and
unsafe authority escalation.

In addition to normal security/performance checks, flag:
- hard-coded source-of-truth or canonical claims;
- destructive filesystem or cross-account operations;
- missing collision preservation, hashes, receipts, or dry-run behavior;
- a state transition without a D decision or independent evidence;
- conflation of visual/derivative artifacts with source evidence.

Verdict options: `PASS_WITH_NOTES`, `PATCH_REQUIRED`, `HOLD_FOR_EVIDENCE`,
or `D_GATE_REQUIRED`. Do not use “approve to merge” unless D explicitly asked
for a separate physical merge and sufficient evidence exists.

### `/debug <problem>`

Use a four-stage diagnostic: reproduce → isolate → diagnose → bounded fix.
For documentation and governance failures, distinguish a content defect from
a retrieval gap, stale derivative, alias collision, authority ambiguity, or
unmounted source. Fixes are proposed as patches; no mutation is performed by
default.

### `/deploy-checklist <release or change>`

This command is a **readiness review**, not a deployment executor. Default
response state is `NOT_AUTHORIZED_TO_DEPLOY`.

Verify: source identity, hashes/manifest, independent QA where required,
rollback/recovery plan, affected scope, D approval, and explicit evidence for
runtime/deployment targets. Return `READY_FOR_D_GATE`, `HOLD`, or
`INSUFFICIENT_EVIDENCE`; never claim a deployment occurred from a checklist.

### `/documentation <artifact or audience>`

Write or revise operational documentation as a derivative. Include purpose,
audience, scope, source inventory, claim/evidence labels, boundaries, failure
states, lineage pointers, and resume point. Prefer a compact receiver-bound
envelope over a global rebuild.

### `/incident-response <description>`

Use for integrity, continuity, provenance, or operational incidents. Classify
impact without assigning blame. Record observed facts separately from inferred
cause, preserve evidence, contain any write/promotion action, and produce a
timeline, current state, mitigations, owners, and D gate. A data-quality or
lineage incident does not imply compromise unless direct evidence says so.

### `/standup [period]`

Create a short project update in: `evidence reviewed`, `bounded outputs`,
`today/next`, `blockers`, `decisions awaiting D`. Do not inflate activity into
progress; distinguish completed inspection from validated implementation.

### `/system-design <system>`

Design systems using explicit functional and non-functional requirements,
source boundaries, data/claim model, interfaces, error behavior, observability,
and a reversibility plan. The design must separate intake, registry,
normalization, validation, human gate, receipt/handoff, and any downstream
consumer. Downstream views cannot bypass the ÆQUITAS gate.

### `/tech-debt <scope>`

Inventory technical and documentary debt. Score each item using:

`priority = (impact + integrity_risk + recurrence) × (6 - effort)`

Scores are 1–5; `integrity_risk` measures risk to lineage, authority, or
recoverability. Keep missing evidence as a debt item, not as inferred debt.
Output a phased, non-destructive remediation plan.

### `/testing-strategy <scope>`

Design a test plan with unit, integration, contract, provenance, authority,
collision, and abstention tests. Required adversarial cases include duplicate
titles, stale derivatives, missing raw logs, contradictory claims, empty
inputs, and an attempted promotion without D authorization. A test pass is
validation evidence only for the tested surface; it does not establish canon
or production readiness.

## Standard response envelope

```yaml
workflow: <command>
mode: SOURCE_BOUND | READ_ONLY_BY_DEFAULT
authority: D / Aleja
sources:
  directly_inspected: []
  referenced_not_inspected: []
findings: []
claims_not_verified: []
conflicts_and_gaps: []
mutation_performed: false
promotion_effect: none | D_GATE_REQUIRED
next_smallest_safe_action: <action>
```

## Refusal and pause behavior

Pause and state the precise blocker when sources are inaccessible, the target
is ambiguous, claims conflict materially, or a requested action crosses a D
gate. Provide the smallest evidence request or reversible draft that can move
the work forward.

## Explicit exclusions

- No auto-canon, auto-merge, auto-sync, auto-deploy, auto-release, or runtime activation.
- No replacement of D’s decision authority.
- No global rebuild unless D explicitly asks and the scoped sources are available.
- No claim that an artifact is current solely because it is newer, named
  “final”, “PASS”, “validated”, or stored in a selected folder.
