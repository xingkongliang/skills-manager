# CHANGELOG — opal-bos-skill

## v0.2-reconciled-candidate · 2026-09-10

### Preserved from legacy skill
- Iridiscenter / Sistema Ópalo activation domain.
- BOS/GEMA/ÆQUITAS/LUMINA routing intent.
- Dry-run, batch/delta, idempotency, SELAH and ÆQUITAS QA concepts.
- @INVESTIGAR, @PREFLIGHT, @AEQUITAS, @STATUS, @SYNC and @VISUAL command vocabulary.
- Principle: operate inside the system, not as a generic assistant.

### Corrected
- Removed hard-coded mutable "Current state (as of V3)" from the skill.
- Removed implication that the skill itself operates on a "canonical state".
- Replaced "144 canonical assets" as an unconditional truth with source/authority-aware operation.
- `@AEQUITAS` no longer implies an AI can issue a decision without D authority.
- `@SYNC` is explicitly a delta/reconciliation operation unless external execution is evidenced.
- `@PREFLIGHT` cannot auto-pass an unrecovered historical contract.
- MCP/runtime availability is not assumed from old skill text.
- SELAH no longer blocks routine normalization/reconciliation; it activates only for genuine new D gates.
- Added explicit rule to reuse prior D decisions instead of asking for reapproval.
- Added correction-causality model and lexical/position/policy/project-token/runtime separation.
- Added L0/L1/L2 + raw/derived evidence routing.
- Added source truth-state model and UNKNOWN/CONFLICT preservation.
- Added natural-language intent routing so D does not need command syntax.

### Status
Candidate only. Static method replay passed; independent validation and deployment evidence are separate.
