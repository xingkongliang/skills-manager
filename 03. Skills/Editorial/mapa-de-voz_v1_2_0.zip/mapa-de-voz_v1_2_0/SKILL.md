---
name: mapa-de-voz
version: 1.2.0
release_status: RELEASED_CANDIDATE
container: VOIEON
commit_label: COMMIT_TO_SKILL_DELIVER_RELEASED
description: >
  Diagnóstico literario interactivo que mapea la voz editorial de un escritor
  en 5 dimensiones (Intensidad, Originalidad, Ritmo, Perspectiva, Riesgo) y
  entrega un perfil arquetípico con 3 ejercicios calibrados, brand tokens LUMINA
  derivados, delta de integración para COMET_VAULT, y un cuadernillo print-ready
  (DOCX editable + PDF) para completar a mano.

  Activa este skill cuando el usuario mencione: mapa de voz, diagnóstico de voz,
  voz literaria, voz editorial, perfil de escritor, descubrir mi voz, voz propia,
  ejercicios de escritura, qué tipo de escritor soy, LUMINA Editorial, Pilar 3
  Iridiscenter, brand identity studio v2, cuadernillo, print-ready, o cuando
  pida renderizar, actualizar o exportar el artefacto Mapa de Voz en cualquier
  formato (React, HTML portable, DOCX, PDF).

  ACTIVA PROACTIVAMENTE cuando el usuario trabaje dentro del metasistema
  Iridiscenter y mencione su voz, estilo o identidad como escritora/creadora.

truth_boundary: >
  Este skill es skill-package completo dentro del contexto de artefacto actual.
  No declarar remote repo commit, production deployment, ni garantía
  Prometheus-packed a menos que sea verificado por evidencia externa /repo/** o
  /runtime/**. El estado de sincronización con el repositorio externo permanece
  como PENDING hasta autorización explícita. Los entregables DOCX/PDF son
  PRINT_READY_CANDIDATE — commercial_final: false hasta revisión humana.
---

# Mapa de Voz — Skill Operativo v1.2.0
**Container:** VOIEON · **Rama:** R3 Editorial LUMINA · **Pilar:** 3
**Estado:** RELEASED_CANDIDATE · **Idioma:** es · **Tokens:** LUMINA canonical

---

## FASE 0 — Clasificar intención

| Modo | Señal | Acción |
|------|-------|--------|
| `render_react` | "test interactivo", "componente React", "VozMap" | → Fase 1A |
| `render_html_interactive` | "HTML", "sin dependencias", "portátil", "localStorage" | → Fase 1B |
| `render_print_ready` | "cuadernillo", "imprimible", "print-ready", "DOCX", "PDF" | → Fase 1C |
| `interpret_scores` | Comparte scores o resultado | → Fase 2 |
| `derive_brand_tokens` | "tokens de mi voz", "paleta", "identidad visual" | → Fase 3 |
| `export_lumina_delta` | Sesión LUMINA activa · "exportar al vault" | → Fase 4 |
| `frontend_upgrade` | "mejorar UI", "actualizar componente", "migrar paleta" | → Fase 5 |
| `editorial_package` | "paquete editorial", "guía completa", "Pilar 3" | → Fase 6 |
| `handoff` | "pasar a otro modelo", "context restore", "nuevo binding" | → Fase 7 |
| `update_skill` | "agrega pregunta", "nuevo perfil", "mejora el skill" | → Fase 8 |

Ejecutar solo el modo activo. Registrar como supuesto si la señal es ambigua.

---

## FASE 1A — render_react
(sin cambios respecto a v1.1.0 — ver `references/brand-tokens.md`)

## FASE 1B — render_html_interactive
(sin cambios respecto a v1.1.0 — HTML autocontenido, localStorage `mdv_*`, radar SVG, export/import snapshot JSON)

---

## FASE 1C — render_print_ready  *(NUEVO en v1.2.0)*

Generar cuadernillo imprimible del diagnóstico, en dos formatos paralelos:

**Fuente canónica de datos:** `data/mapa_voz_data.json` (preguntas + perfiles + pilares — mismos vectores `s[5]` que `references/scoring.md`)

**DOCX** (`generators/mapa_voz_docx.py` — `python-docx`, sigue el patrón de helpers `add_run` / `add_hr` / `add_selah_box` ya establecido en `gen_docx.py` de THE NINŒ 369, por fidelidad al patrón del proyecto):
- Página de portada + nota editorial
- Los 5 pilares (bridge desde `brujula_de_voz.html`)
- Instrucciones de scoring
- 5 preguntas con checkbox editable (☐) por opción
- Página de Cartografía con placeholder de radar de 5 puntas para dibujar a mano
- 5 páginas de perfil: descripción + 3 ejercicios + caja de escritura (patrón SELAH, 5 líneas)
- Colofón con truth boundary

**PDF** (`generators/mapa_voz_pdf.py` — `reportlab`, A5, `Checkbox`/`RadarBlank` como `Flowable` custom, checkboxes alineados en `Table` de 2 columnas):
- Misma estructura que el DOCX
- `RadarBlank`: pentágono vectorial dibujado a mano alzada por el usuario, con grid de 25/50/75/100% y ejes etiquetados
- Colores: fondo Crema `#F5F1EC`, texto Carbón `#202428`, accents Oro RB `#CC9C50` / Rose Gold `#C48B7A`, color por perfil desde `color_lumina`
- Fuentes: fallback `Times-Roman`/`Helvetica` (Playfair Display/Montserrat no embebidas — declarar en colofón)

**Reglas:**
- Ambos formatos se generan desde el mismo JSON — nunca hardcodear contenido duplicado entre generadores
- Verificar visualmente antes de entregar: `soffice --convert-to pdf` + `pdftoppm` para DOCX; `pdftoppm` directo para PDF (regla del skill `docx`/`pdf`)
- Nombrar archivos: `CUADERNILLO_MAPA_DE_VOZ_v{version}_PRINT_READY_CANDIDATE.pdf` / `CUADERNILLO_MAPA_DE_VOZ_EDITABLE_v{version}.docx`
- No afirmar `commercial_final: true` sin revisión humana explícita

**Output esperado:**
```json
{
  "artifact_type": ["docx", "pdf"],
  "title": "Cuadernillo Mapa de Voz",
  "version": "1.2.0",
  "pages": 16,
  "print_ready_candidate": true,
  "commercial_final": false,
  "font_policy": "fallback_system_fonts"
}
```

---

## FASE 2 — interpret_scores
(sin cambios respecto a v1.1.0)

## FASE 3 — derive_brand_tokens
(sin cambios respecto a v1.1.0)

## FASE 4 — export_lumina_delta
(sin cambios respecto a v1.1.0)

## FASE 5 — frontend_upgrade
(sin cambios respecto a v1.1.0; agregar `render_print_ready` a la lista de migraciones disponibles: "Sin cuadernillo → con cuadernillo DOCX+PDF (Fase 1C)")

## FASE 6 — editorial_package
Agregar punto 7: "El cuadernillo print-ready (DOCX editable + PDF) como material de regalo o venta física."

## FASE 7 — handoff

```
[MAPA DE VOZ · CONTEXT RESTORE · v1.2.0]
Container: VOIEON
Skill: mapa-de-voz RELEASED_CANDIDATE
Rama: R3 Editorial LUMINA · Pilar 3
Modos disponibles: render_react · render_html_interactive · render_print_ready ·
                   interpret_scores · derive_brand_tokens · export_lumina_delta ·
                   frontend_upgrade · editorial_package · handoff · update_skill
Brand tokens: Playfair Display / Montserrat · #CC9C50 · #C48B7A · #F5F1EC · #202428
Perfiles: 5 · Dimensiones: 5 · Preguntas: 5 · Ejercicios: 15
Formatos de salida: jsx · html_portable · docx · pdf
ÆQUITAS activo · Idioma: es
Referencias: profiles.md · scoring.md · brand-tokens.md · data/mapa_voz_data.json
[FIN CONTEXT RESTORE]
```

## FASE 8 — update_skill
(sin cambios de proceso respecto a v1.1.0)

---

## QC CHECKLIST

```
QC-01  Modo clasificado antes de ejecutar
QC-02  Fuente canónica correcta según modo (jsx · html · docx · pdf · profiles.md · scoring.md)
QC-03  Brand tokens: lumina_canonical si sesión Iridiscenter · original si no
QC-04  norm[i] = round((totals[i] / 25) × 100)
QC-05  domIdx = indexOf(max(totals)) — winner-takes-all
QC-06  Exactamente 3 ejercicios por perfil entregado
QC-07  Delta LUMINA emitido en integration_mode: enrichment_observation
QC-08  Snapshot JSON válido si modo render_html_interactive
QC-09  Voz: elegante · invitacional · precisa (director-editorial-sistemico)
QC-10  changelog_entry emitido si skill fue modificado
QC-11  render_print_ready: DOCX y PDF verificados visualmente (soffice+pdftoppm) antes de entregar; 5 perfiles con caja de escritura; radar en blanco con 5 ejes
```

---

## CHANGELOG

```
v1.2.0 — Nueva Fase 1C (render_print_ready): cuadernillo DOCX editable + PDF
         imprimible A5, generado desde data/mapa_voz_data.json compartido.
         Bump MINOR (nuevo modo, sin cambios de scoring).
v1.1.0 — Fase 1B (render_html_interactive) + snapshot JSON portable.
```

---

## TRUTH BOUNDARY ACTIVA

```
remote_repo_commit:    NOT_VERIFIED — requiere /repo/** externo
production_deployment: NOT_VERIFIED — requiere /runtime/**
prometheus_guarantee:  PENDING — /approve-dry-run no recibido aún
skill_install_status:  CANDIDATE — no instalado en perfil hasta acción explícita
localStorage_scope:    browser-local — no persiste entre dispositivos sin export JSON
print_ready_status:    PRINT_READY_CANDIDATE — commercial_final: false hasta revisión humana
font_embedding:        NOT_EMBEDDED — DOCX/PDF usan fuentes de sistema de fallback
```

---

## REFERENCIAS (lazy-load)

| Archivo | Cuándo leer |
|---------|-------------|
| `references/profiles.md` | Fases 2, 3 — perfiles, ejercicios, colores |
| `references/scoring.md` | Fases 2, 4 — algoritmo, DIMS, bridge LUMINA |
| `references/brand-tokens.md` | Fases 1A, 1B, 1C, 3, 5 — paleta, tipografía, voice tokens |
| `data/mapa_voz_data.json` | Fase 1C — fuente única de preguntas/perfiles para DOCX+PDF |
| `generators/mapa_voz_docx.py` | Fase 1C — generador DOCX |
| `generators/mapa_voz_pdf.py` | Fase 1C — generador PDF |

Leer solo lo necesario. No pre-cargar todo en cada invocación.
