# Historical Assignments — Preserved Events (Downgraded / Retracted)

**Source:** ACCOUNT_TOPOLOGY_REBUILD_ADVICE  
**Purpose:** These are facts about what happened on certain dates. They are NOT identity evidence. Preserved so the audit trail is complete.

---

## Downgraded Assignments

```yaml
2026-08-20:
  setaleablaze@hotmail.com:
    historical_assignment: CLD_00
    basis: HUMAN_ASSIGNED_NON_VIRGIN_VIRGIN
    epistemic_status: HISTORICAL_HUMAN_ASSIGNMENT
    current_identity_evidence: INVALID_AS_IDENTITY_PROOF
    action: PRESERVE_AS_EVENT_ONLY

  raquelalejandrab91@gmail.com:
    historical_assignment: CLD_01
    basis: HUMAN_ASSIGNED_NON_VIRGIN_VIRGIN
    epistemic_status: HISTORICAL_HUMAN_ASSIGNMENT
    current_identity_evidence: INVALID_AS_IDENTITY_PROOF
    action: PRESERVE_AS_EVENT_ONLY
```

## Retracted Assignments

```yaml
retracted:
  - account: alejaisablaze@outlook.com
    logical_id: CLD_04
    status: RETRACTED
    reason: explicit D correction (2026-08-18)
    action: DO_NOT_ASSIGN — must remain without CLD ID until explicit evidence

downgraded:
  - account: setaleablaze@hotmail.com
    logical_id: CLD_00
    status: HISTORICAL_ONLY
    reason: human non-virgin/virgin assignment is methodologically insufficient

  - account: raquelalejandrab91@gmail.com
    logical_id: CLD_01
    status: HISTORICAL_ASSIGNMENT_EVENT_ONLY
    reason: same methodological defect

  - any_CLD_02_or_CLD_03_mapping based on:
      role, content, style, project_ownership, elimination
    status: INVALID_AS_IDENTITY_EVIDENCE
```

## Contradicted Hypotheses

```yaml
hypothesis_events:
  - claim: iridiscenterinc@gmail.com → CLD_03
    date_of_hypothesis: 2026-08-18
    source_at_hypothesis: AEQ_IDENTITY_ANCHOR_AUDIT_CLD_03_v0_1
    date_of_contradiction: 2026-08-18
    contradicting_source: ACCOUNT_TOPOLOGY_REBUILD_ADVICE (D_CONFIRMED)
    resolution: iridiscenterinc@gmail.com = CLD_00 (D_CONFIRMED) · CLD_03 email = UNKNOWN
    audit_artifact: AEQ_IDENTITY_ANCHOR_AUDIT_CLD_03_v0_2_CORRECTION
```

