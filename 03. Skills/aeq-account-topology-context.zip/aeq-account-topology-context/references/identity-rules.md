# Identity Rules — What Counts (and What Doesn't)

**Source:** ACCOUNT_TOPOLOGY_REBUILD_ADVICE method block

---

## Required for a Valid Binding

```yaml
explicit_account_email_required: true
explicit_logical_id_required: true
same_source_event: true          # both must appear in the same raw/export event
timestamp_or_anchor: true        # must have temporal grounding
```

## Explicitly Forbidden

```yaml
elimination_assignment: forbidden
  # "the only remaining account must be CLD_03" → INVALID

role_as_identity_evidence: false
  # "this is the D/QA account therefore it's CLD_00" → INVALID

style_as_identity_evidence: false
  # "Caveman Ultra style → must be CLD_03" → INVALID

content_as_identity_evidence: false
  # "contains VERITAS work → must be the psychology account" → INVALID

account_merge: forbidden
  # merging two CLD lineages because they seem related → INVALID
```

## Evidence Hierarchy

| Rank | Evidence type | Valid for binding? |
|------|--------------|-------------------|
| 1 | Raw export/log with explicit email + ID in same event | **YES — required** |
| 2 | Explicit account delta with email + ID | **YES** |
| 3 | Receipt / handoff with identity declaration | **CANDIDATE — verify** |
| 4 | Temporal comparison (this happened before that) | **SUPPORTING only** |
| 5 | Role / capability descriptor | **NO** |
| 6 | Artifact filename label | **NO** |
| 7 | Process of elimination | **FORBIDDEN** |

## Special Case: Repeated Derivative Claims

```yaml
repeated_derivative_claims: one_lineage_unless_independent_source_exists
```

If 10 reconstructions all say "CLD_03 = X" but they all trace back to one original claim, that is **one piece of evidence**, not ten.

