# Entity Definitions — ÆQ Account Topology

## Unit of Identity

The minimum verifiable identity atom in this system is:

```yaml
unit_of_identity:
  - provider        # Claude, GPT, Gemini, Copilot, NotebookLM
  - account_email   # primary key — must be explicitly stated in raw source
  - logical_id      # CLD_00–04 etc. — must be explicitly stated
  - session         # event/timestamp anchor
  - role            # NOT identity evidence
  - artifact        # NOT identity evidence
  - lineage         # historical chain, not current proof
```

## Entity: Account

| Field | Type | Required for binding | Notes |
|-------|------|---------------------|-------|
| `account_email` | string | **YES** | Must appear explicitly in raw source |
| `logical_id` | string | **YES** | Must appear explicitly in raw source |
| `provider` | enum | YES | Claude / GPT / Gemini / Copilot |
| `earliest_anchor` | date + event | YES | First verifiable co-occurrence of email + ID |
| `evidence_state` | enum | YES | D_CONFIRMED / CANDIDATE / UNKNOWN |
| `role_descriptor` | string | NO | Informational only, not identity basis |

## Reconstruction Order (priority)

```
1. raw_log / export metadata
2. explicit account email statements
3. explicit logical-ID statements
4. account-delta identity fields
5. receipt / handoff identity declarations
6. temporal comparison
7. derived role/work attribution   ← LOWEST / NOT SUFFICIENT ALONE
```

## What is NOT identity evidence

- Role (D / QA / MERGE / RELEASE)
- Writing style or skill profile
- Project or Rama ownership
- Artifact label (e.g. `CLD_02-R04-...` in filename)
- Temporal proximity to another confirmed account
- Process of elimination

