# Open Unknowns — ÆQ Account Topology

**Source:** ACCOUNT_TOPOLOGY_REBUILD_ADVICE U-series

---

| ID | Target | Question | Status |
|----|--------|----------|--------|
| **U-01** | CLD_02 | Which account_email belongs to CLD_02? | **OPEN** |
| **U-02** | CLD_03 | Which account_email belongs to CLD_03? | **OPEN** |
| **U-03** | CLD_03 | What exactly was the historical mapping? | **OPEN** |
| **U-04** | all CLD IDs | Are there duplicate logical IDs across accounts? | **NOT_ESTABLISHED** |
| **U-05** | CLD_00 / CLD_01 | Exact earliest raw-source identity anchor? | **BOUNDED_BY_RECONSTRUCTION** |
| **U-06** | ChatGPT-Reanudar Delta Claude-20260821-1108.json | 20/08 assignment event not independently inspectable | **NOT_FOUND_AS_DIRECT_SOURCE** |
| **U-07** | Full CLD_00–04 topology | Complete matrix | **INCOMPLETE** (CLD_02/03 absent) |

---

## What Cannot Close These Unknowns

- Role attribution ("this account did governance work")
- Style or skill profile matching
- Artifact filename labels (e.g. `CLD_02-R04-...`)
- Summaries or handoffs derived from the same original claim
- Process of elimination

## What Can Close These Unknowns

For each unknown:
```text
Raw Claude export containing:
  explicit account email
  + explicit CLD_02 / CLD_03 designation
  + session timestamp or export metadata
```

