# Account-to-ID Matrix — Current Assignments

**Source:** ACCOUNT_TOPOLOGY_REBUILD_ADVICE (D_CONFIRMED · 2026-08-18)  
**No_merge:** true | **No_canon:** true | **No_mutation:** true

---

## Current Assignments

| Logical ID | account_email | earliest_anchor | evidence_state | Role descriptor |
|-----------|--------------|----------------|---------------|----------------|
| **CLD_00** | `iridiscenterinc@gmail.com` | 2026-08-18 governance/foundational lineage | **D_CONFIRMED** | GOVERNANCE / FOUNDATIONAL |
| **CLD_01** | `raquelalejandrab91@gmail.com` | 2026-08-20 account verification / reconciliation lineage | **D_CONFIRMED** | RECONCILIATION / AUDIT |
| **CLD_02** | **UNKNOWN** | artifacts labelled CLD_02 exist (CLD_02-R04_RB...) | **INSUFFICIENT** | artifact label ≠ account identity |
| **CLD_03** | **UNKNOWN** | historical references exist | **HISTORICAL_REFERENCE_ONLY** | no primary source found |
| **CLD_04** | `hi.im.ajelet.sahar@gmail.com` | multiple later documentary/raw-log references | **D_CONFIRMED** | — |
| *(unassigned)* | `alejaisablaze@outlook.com` | D correction 2026-08-18 | **D_CONFIRMED / UNASSIGNED** | prior CLD_04 mapping INVALIDATED |

---

## Key Notes per Account

### CLD_00 — `iridiscenterinc@gmail.com`
```yaml
recommended_next_source:
  - original 2026-08-18 Claude export/raw metadata
  - account/session metadata containing explicit email
caution:
  - historical 2026-08-20 assignment to setaleablaze@hotmail.com is DOWNGRADED
  - that assignment was human/non-virgin/virgin — not identity evidence
```

### CLD_01 — `raquelalejandrab91@gmail.com`
```yaml
recommended_next_source:
  - original CLD_01 identity-verification event
  - raw Claude export/session metadata
caution:
  - historical 2026-08-20 assignment is DOWNGRADED to historical event
  - not valid identity proof; preserved as event only
```

### CLD_02 — UNKNOWN
```yaml
important:
  - artifact_label ≠ account identity
  - project/Rama ownership ≠ account identity
recommended_next_source:
  - original Claude export with explicit account email
  - raw session metadata
  - CLD_02 account delta
```

### CLD_03 — UNKNOWN
```yaml
important:
  - hypothesis iridiscenterinc@gmail.com → CLD_03 is CONTRADICTED (email = CLD_00)
  - historical references preserved as event only
recommended_next_source:
  - original CLD_03 raw export
  - account/session metadata
  - explicit CLD_03 account delta
```

### CLD_04 — `hi.im.ajelet.sahar@gmail.com`
```yaml
important:
  - alejaisablaze@outlook.com mapping INVALIDATED — do not use as fallback
recommended_next_source:
  - raw log with explicit email + CLD_04 in same event (earliest anchor)
```

---

## Recommended Priority for Closing Unknowns

```
1. Do NOT re-litigate CLD_00 / CLD_01 (lineage sufficiently separated)
2. Attack CLD_02 first (artifacts exist as starting point)
3. Attack CLD_03 second
4. Require for each: Claude account email + logical ID + timestamp in same raw source
5. Check for duplicate IDs after — not before
```

