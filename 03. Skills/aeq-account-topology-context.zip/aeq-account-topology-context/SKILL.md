---
name: aeq-account-topology-context
description: >
  Reference skill for the ÆQ multi-AI system account topology.
  Provides structured identity rules, account-to-ID matrix, entity definitions,
  prohibited inferences, and open unknowns. Use at the start of any session
  that involves Claude account routing, ID assignment, or multi-AI sync.
sources: [ACCOUNT_TOPOLOGY_REBUILD_ADVICE · D_CONFIRMED · 2026-08-18]
---

# ÆQ Account Topology Context

## System: IRIDISCENTER Metasystem — Claude Account Registry

**Evidence state of this document:** D_CONFIRMED for CLD_00, CLD_01, CLD_04 / UNKNOWN for CLD_02, CLD_03  
**Canon declared:** false  
**Mutation allowed:** false  
**Last updated:** 2026-08-18

---

## Knowledge Base Navigation

| File | Domain | When to use |
|------|--------|-------------|
| `references/entities.md` | Account entity definitions + unit of identity | Start here |
| `references/account-matrix.md` | Account-to-ID matrix (current + historical) | Routing decisions |
| `references/identity-rules.md` | What counts as identity evidence — and what doesn't | Before any ID assignment |
| `references/unknowns.md` | Open unknowns — CLD_02, CLD_03, unresolved items | Before claiming completeness |
| `references/historical-events.md` | Downgraded / retracted assignments, preserved events | Audit / lineage queries |

---

## Critical Rules (inline)

```yaml
elimination_assignment: forbidden
role_as_identity_evidence: false
style_as_identity_evidence: false
content_as_identity_evidence: false
artifact_label_as_account_identity: false
account_merge: forbidden
canon: false
mutation: false
```

**Never infer CLD_02 or CLD_03 from role, style, project ownership, or elimination.**

