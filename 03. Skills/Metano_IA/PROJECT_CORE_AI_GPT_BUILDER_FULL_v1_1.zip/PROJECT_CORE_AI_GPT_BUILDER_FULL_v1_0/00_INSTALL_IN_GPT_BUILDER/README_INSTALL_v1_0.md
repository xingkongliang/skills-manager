# Install Guide · Project Core AI · Full Package v1.0

## Qué es este paquete
Este paquete consolida el build actual para crear tu GPT personalizado en GPT Builder.

- `01_COPY_PASTE_FIELDS/` contiene Nombre, Descripción, Instrucciones completas y frases iniciales.
- `02_UPLOAD_READY_CORE_KNOWLEDGE_FILES/` contiene los archivos que sí conviene subir primero como knowledge files.
- `03_CANONICAL_CORE_BUNDLES_CLAUDE/` preserva los bundles Claude declarados CORE.
- `04_CANONICAL_PROJECT_FILES_CLAUDE/` preserva archivos canónicos del proyecto Codex/BOS/METANO_IA.
- `05_CHATGPT_ASSEMBLY_OVERLAY/` conserva los paquetes generados aquí para instalar/reacoplar el GPT.
- `07_REGISTRY_AND_MANIFESTS/` contiene el inventario, manifest y discriminación por AI/origen.

## Orden exacto en GPT Builder

1. Nombre: copiar desde `01_COPY_PASTE_FIELDS/GPT_BUILDER_FIELDS_v1_0.md`.
2. Descripción: copiar desde el mismo archivo.
3. Instrucciones: pegar `01_COPY_PASTE_FIELDS/FULL_GPT_BUILDER_INSTRUCTIONS_v1_0.txt`.
4. Frases iniciales: pegar desde `01_COPY_PASTE_FIELDS/CONVERSATION_STARTERS_v1_0.txt`.
5. Conocimientos: subir archivos de `02_UPLOAD_READY_CORE_KNOWLEDGE_FILES/` en orden numérico, empezando por `00_PROJECT_CORE_AI_SELAH_OPAL_BOS_ORCHESTRATOR_v1_0_1.skill.md` (skill madre portátil, sube primero).
6. Activar capacidades: web browsing, canvas, image generation, code interpreter / data analysis.
7. Probar con los prompts en `SMOKE_TESTS_v1_0.md`.

## Regla de autoridad

Los bundles Claude aprobados por Raquel son CORE. Los paquetes ChatGPT son overlay de ensamblaje/instalación y no sustituyen el canon Claude sin aprobación explícita.

## Fecha
2026-07-01T01:36:31Z

## Delta v1.1
2026-07-01 · Se añade `00_PROJECT_CORE_AI_SELAH_OPAL_BOS_ORCHESTRATOR_v1_0_1.skill.md` como skill portátil madre (contrato operativo transversal Claude/ChatGPT/Gemini). No reemplaza las instrucciones compactas de GPT Builder; viaja como primer knowledge file.
