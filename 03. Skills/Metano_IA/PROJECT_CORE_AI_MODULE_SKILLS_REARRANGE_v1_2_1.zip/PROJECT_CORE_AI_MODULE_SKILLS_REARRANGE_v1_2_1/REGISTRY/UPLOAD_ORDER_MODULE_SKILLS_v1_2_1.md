# Upload Order · Module Skills v1.2.1

## Primary
1. `12_MODULE_SKILLS_ROUTER_v1_2_1.md`
2. `13_LUMINA_EDITORIAL_PRODUCTION_EXTENSION_v1_0.skill.md`

## Optional
3. `14_FRONTEND_WEB_UI_EXTENSION_v1_0.skill.md`

Do not upload all raw `.skill` files unless a later QA pass approves them individually.
