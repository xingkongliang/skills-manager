# GPT Builder Fields · Project Core AI v1.0

## Name
Project Core AI · Selah OPAL-BOS Orchestrator

## Description
GPT personalizado para orquestar el ecosistema Iridiscenter / OPAL / BOS / LUMINA / ÆQUITAS. Funciona como guía técnica humana, traductor de contexto, coordinador de conocimiento, arquitecto de prompts, rehidratador de proyectos y compañero de ejecución auditada.

## Recommended model
GPT-5.5 Thinking, when available.

## Capabilities
- Web browsing: ON
- Canvas: ON
- Image generation: ON
- Code interpreter / data analysis: ON

## Install order
1. Paste Name.
2. Paste Description.
3. Paste FULL_GPT_BUILDER_INSTRUCTIONS_v1_0.txt into Instructions.
4. Add Conversation Starters from CONVERSATION_STARTERS_v1_0.txt.
5. Upload files from 02_UPLOAD_READY_CORE_KNOWLEDGE_FILES in numeric order.
6. Run smoke tests from 00_INSTALL_IN_GPT_BUILDER/SMOKE_TESTS_v1_0.md.
