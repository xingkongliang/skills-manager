# Use Compact Instructions Only · v1.1.1

GPT Builder instruction field limit: 8000 characters.

Paste ONLY:

`01_COPY_PASTE_FIELDS/GPT_BUILDER_INSTRUCTIONS_COMPACT_UNDER_8000_v1_1_1.txt`

Character count: 6049.

Do NOT paste `FULL_GPT_BUILDER_INSTRUCTIONS_v1_0.txt` into GPT Builder; it is retained as archive/context only and exceeds the limit.
