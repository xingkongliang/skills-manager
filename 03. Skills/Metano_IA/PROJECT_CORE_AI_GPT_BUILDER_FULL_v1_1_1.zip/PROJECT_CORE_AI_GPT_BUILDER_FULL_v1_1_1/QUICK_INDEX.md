# PROJECT_CORE_AI_GPT_BUILDER_FULL_v1_1_1 · Quick Index

Primary artifacts:
- Full package ZIP: `PROJECT_CORE_AI_GPT_BUILDER_FULL_v1_1_1.zip`
- Upload-ready core ZIP: `PROJECT_CORE_AI_GPT_BUILDER_UPLOAD_READY_CORE_v1_0.zip`

Key files:
- `00_INSTALL_IN_GPT_BUILDER/README_INSTALL_v1_0.md`
- `01_COPY_PASTE_FIELDS/GPT_BUILDER_INSTRUCTIONS_COMPACT_UNDER_8000_v1_1_1.txt`
- `02_UPLOAD_READY_CORE_KNOWLEDGE_FILES/`
- `07_REGISTRY_AND_MANIFESTS/FULL_PACKAGE_MANIFEST_v1_0.json`
- `07_REGISTRY_AND_MANIFESTS/AI_ORIGIN_FILE_INVENTORY_v1_0.csv`

Rule: Claude bundles approved by Raquel are CORE; ChatGPT packages are assembly overlay.

## Delta v1.1
- Nuevo: `02_UPLOAD_READY_CORE_KNOWLEDGE_FILES/00_PROJECT_CORE_AI_SELAH_OPAL_BOS_ORCHESTRATOR_v1_0_1.skill.md` (skill portátil madre, sube primero como knowledge file).

## Delta v1.1.1
- Corrección: instrucciones compactas bajo 8000 caracteres: `6049` chars.
- `FULL_GPT_BUILDER_INSTRUCTIONS_v1_0.txt` queda como archivo histórico/contextual; no pegar en GPT Builder.
- `00_PROJECT_CORE_AI_SELAH_OPAL_BOS_ORCHESTRATOR_v1_0_1.skill.md` confirmado como primer knowledge file.
