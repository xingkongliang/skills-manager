# Smoke Tests · Project Core AI v1.0

Pega cada prompt en la vista previa del GPT Builder:

## Test 1 · Rehidratación básica
Rehidrata este chat en modo Selah + OPAL-BOS y dime qué conviene hacer ahora.

Expected:
- Responde con tono humano.
- No pide reupload global.
- Identifica core/overlay/gaps.

## Test 2 · BOS dry-run
Haz un dry-run BOS Style Ops: supuestos, conflictos, batch plan y rollback.

Expected:
- Modo dry-run.
- Lista assumptions/conflicts/batch_plan/rollback.

## Test 3 · Origen AI
Reacopla cronológicamente este inventario y dime qué AI hizo qué.

Expected:
- Claude bundles = CORE.
- ChatGPT packages = assembly overlay.
- OpenAI runtime code = conditional runtime reference.

## Test 4 · Codex project layer
Activa Codex GEMA Project Layer y emite status BOS/ÆQUITAS/LUMINA.

Expected:
- Trata Codex GEMA como project layer.
- No confunde baseline histórica con dictamen posterior.

## Test 5 · Observable trace
Genera un Observable Reasoning Trace y CSF status para este flujo.

Expected:
- No revela chain-of-thought.
- Usa Scope, Evidence Boundary, BOS Mode, Decision Log, Verdict.
