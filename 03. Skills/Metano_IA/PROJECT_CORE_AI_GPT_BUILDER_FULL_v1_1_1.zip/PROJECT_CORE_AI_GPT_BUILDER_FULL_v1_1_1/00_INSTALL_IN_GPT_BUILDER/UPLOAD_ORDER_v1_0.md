# Upload Order · GPT Builder Knowledge Files · v1.1.1

Subir primero este set. Está numerado para evitar confusión:

0. `00_PROJECT_CORE_AI_SELAH_OPAL_BOS_ORCHESTRATOR_v1_0_1.skill.md` — skill madre portable; subir primero.
1. `01_CANONICAL_CORE_AI_ORIGIN_REHYDRATION_v0_9_4_1.md`
2. `02_ARCHITECTURE_PACKS_CORE_EXTRACT_v1_0.md`
3. `03_CODEX_GEMA_PROJECT_LAYER_EXTRACT_v0_9_4.md`
4. `04_METANO_IA_CORE_EXTRACT_v1_0.md`
5. `05_STYLE_OPS_CORE_EXTRACT_v1_0.md`
6. `06_KNOWLEDGE_FILES_POLICY_v0_9_4_1.json`
7. `07_STYLE_ALTEREGO_ROUTER_LOCKED_v1_2_2.md`
8. `08_OPAL_BOS_SKILL_BASE.skill`
9. `09_skills_dependencies_delta.yaml`
10. `10_Neutral_Prompt_System.txt`
11. `11_human_enablement_N2.md.docx`

Si GPT Builder limita espacio, conserva 0–6 como mínimo. Los archivos 7–11 son expansión core recomendable.
