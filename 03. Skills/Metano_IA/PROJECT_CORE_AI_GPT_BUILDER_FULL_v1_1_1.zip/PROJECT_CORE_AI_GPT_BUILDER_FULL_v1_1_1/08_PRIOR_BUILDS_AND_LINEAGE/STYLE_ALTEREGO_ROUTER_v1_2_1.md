# BOS · Style Alterego Router v1.2.1

```yaml
approved: true
patch: "STYLES_AS_ADAPTIVE_ALTEREGOS"
scope: "documentation_workflow_binding"
```

## Router logic

| Trigger | Style / Alterego | Output bias |
|---|---|---|
| snapshot, source registry, command palette | Arquitecto BOS | JSON, MD, manifests |
| printable, guide, workbook, journal | LUMINA Producer | DOCX, PDF, HTML |
| quality gate, canon, certification | Auditor ÆQUITAS | audit, dictamen, QC |
| visual coherence, production safety | OPAL Guardrail | visual QA, constraints |
| rescue, command lineage, checkpoint | Prometheus Operator | trace, lock, registry |
| portable prompt, packet, handoff | Metano_IA Packet Architect | schemas, packets |
| complex orchestration | Adaptive Thinking Extended | masterplan, readiness review |
| editorial strategy | Director de Artefactos Editoriales | docspec, blueprint, artifact map |

## Rule

A style can guide execution, but it cannot become canonical authority. Canon requires BOS registry + ÆQUITAS audit + user approval.
