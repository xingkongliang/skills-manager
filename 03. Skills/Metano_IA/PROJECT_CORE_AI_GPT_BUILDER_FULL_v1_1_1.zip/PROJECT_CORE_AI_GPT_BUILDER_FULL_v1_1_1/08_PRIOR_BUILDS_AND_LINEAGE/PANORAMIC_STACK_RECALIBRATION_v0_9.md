# PANORAMIC STACK RECALIBRATION v0.9

- generated_at_utc: `2026-06-29T05:22:59.090925+00:00`
- scope: current mounted evidence + style/skill/governance stack
- mode: dry-run / no writes to source packages
- verdict: useful; include as layered knowledge, not flat prompt

## 1. Observable Reasoning Trace

### Scope
Current request is not to finalize canon; it is to recalibrate GPT Builder knowledge and current prompt stack.

### Evidence boundary
32 mounted files found; 20 zip-like packages inspected for manifests/contents.

### Panoramic finding
The stack is coherent: Selah/N2 human layer + Style Alterego router + BOS Style Ops + OPAL-BOS skill + KOP dependency chain + Metano continuity.

### Risk
Do not flatten all packages into active instructions; use layered activation or GPT becomes contradictory/heavy.

### Verdict
Promote v1.2.2 router, OPAL-BOS, BOS Style Ops, METANO_IA, Neutral Prompt System, and N2/Selah into active core; keep older router versions as lineage.

## 2. Inclusion Map

### Active Core
- `STYLE_ALTEREGO_ROUTER_LOCKED_v1_2_2.md` — **active router**: LOCKED execution-style router; use as current router
- `opal-bos-skill.skill` — **skill base**: OPAL/BOS Critical Apparatus; dry-run, SELAH, QA embedded
- `05_B PACK_ADAPTER_BOS_STYLE_OPS_v1_0.txt` — **execution kernel**: dry-run, batch plan, decision log, rollback
- `skills_dependencies_delta.yaml` — **skill dependency map**: KOP inventory→classify→extract→traceability→QA→rehydrate→freeze→export
- `human_enablement_N2.md.docx` — **human layer**: Selah/N2; human enablement, not technical noise
- `METANO_IA_v1.0.zip` — **continuity/prompt architecture**: portable prompt + memory snapshot + role split
- `Neutral Prompt System.txt` — **recovery protocol**: Delegated recovery + Observable Reasoning Trace
- `iridiscenter_portable_script_v2 (1).txt` — **metasystem script candidate**: GEMA/BOS + ÆQUITAS + LUMINA branches; DRAFT pending approval
- `OPAL-PROD-GOVERNANCE.json` — **repo governance snapshot**: GitHub branch rules snapshot; enforcement disabled

### Lineage / Reference
- `STYLE_ALTEREGO_ROUTER_LOCKED_v1_2_1.md` — lineage reference
- `STYLE_ALTEREGO_ROUTER_v1_2_1.md` — pre-lock reference
- `STYLE_ALTEREGO_ROUTER_LOCKED_v1_2_1.csv` — router CSV lineage
- `STYLE_ALTEREGO_ROUTER_v1_2_1.csv` — router CSV pre-lock
- `BOS_REFERENCE_PATCH_v1_2_2_APPROVED_20260603.zip` — approved patch evidence
- `BOS_UNIFIED_APPROVED_EXPORT_v1_2_1_20260602.zip` — prior approved export evidence
- `BOS_UNIFIED_PATCH_v1_2_1_STYLES_APPROVED_20260602.zip` — style patch lineage

### Conditional Skill / Task-Specific
- `SKILL.md` — DOCX production/editing skill; activate for .docx only
- `codex-automation-engineer-style.skill` — Codex automation style; activate for automation/engineering executions
- `STYLE_OPS_UNIFIED_ARCHITECTURE_PACK_v1_0_20260602.zip` — full Style Ops reference/artifact pack; use for docs/assets/audit, not always-on prompt

## 3. Recalibrated Role Name

**Project Core AI · Selah OPAL-BOS Orchestrator**

Aliases: `Vault Orchestrator`, `Context Director`, `Metano_IA Packet Architect`, `BOS Execution Planner`, `ÆQUITAS-aware Continuity Companion`.

## 4. Current Stack Contract

```yaml
stack_contract_v0_9:
  human_layer: Selah Protocol / N2 Human Enablement
  router_layer: STYLE_ALTEREGO_ROUTER_LOCKED_v1_2_2
  skill_base: OPAL-BOS Skill
  execution_layer: BOS Style Ops Adapter
  dependency_layer: KOP Skills Dependency Chain
  continuity_layer: METANO_IA v1.0
  recovery_layer: Neutral Prompt System v0.6.1
  governance_layer: OPAL-PROD-GOVERNANCE snapshot + ÆQUITAS
  rule: layered activation, not flat merge
```

## 5. Gate Verdicts

```yaml
discovery_completeness_accessible_corpus: PASS_FOR_CURRENT_MOUNT
evidence_recording: PARTIAL_PASS_METADATA_AND_ZIP_MANIFEST_DONE
registry_completeness: NOT_YET_FINAL_NEEDS_REGISTRY_WRITE
native_source_corpus: INCOMPLETE_BY_DESIGN
gpt_builder_readiness: READY_FOR_v0_9_INSTRUCTIONS_DRAFT
full_native_archival_status: BLOCKED_UNLESS_ORIGINAL_RAW_EXPORTS_REQUIRED
```

## 6. CSF Status

- **No Global Reupload First**: `PASS` — Accessible runtime and ZIP packages were inspected before asking for more.
- **Scoped Completeness Allowed**: `PASS` — Current goal can be GPT Builder scoped knowledge, not full native archive.
- **Full Native Not Overclaimed**: `PASS` — Native corpus remains incomplete unless originals are declared required.
- **Source vs Derivative Integrity**: `RISK_MANAGED` — Some ZIPs are generated bundles; classify as derivative/registry unless native role is proven.
- **Business/Human Content Cleanly Separated**: `PASS` — Selah/N2 remains user-facing; BOS/KOP remain background execution.
- **No Orphan Claims**: `RISK` — A formal claim-to-evidence registry has not been written yet.
- **Hard Gaps Isolated**: `PASS_SCOPED` — No new reupload needed for GPT Builder v0.9; hard gaps only matter for full-native archive.
- **Migration Verification With Gaps**: `PARTIAL` — Manifest and lineage evidence exists; crosswalk still needs formal registry output.

## 7. Next Action

Proceed to `PROJECT_CORE_AI_GPT_BUILDER_v0_9` instructions draft with sections: name, description, instructions, knowledge file policy, conversation starters, activation commands, CSF checks, and conditional skills.

## 8. Inventory Pointer

Full generated scan inventory: `STACK_SCAN_INVENTORY_v0_9.json`
