# BOS · Style Alterego Router LOCKED
## v1.2.1 · Approved

```yaml
router_id: "STYLE_ALTEREGO_ROUTER_LOCKED_v1_2_1"
approved: true
status: "LOCKED"
patch: "STYLES_AS_ADAPTIVE_ALTEREGOS"
authority: "execution_adapter_not_canonical_authority"
governed_by: "BOS"
audited_by: "ÆQUITAS"
editorialized_by: "LUMINA"
constrained_by: "OPAL"
```

## Locked router

| Trigger | Style / Alterego | Output bias | Gate |
|---|---|---|---|
| snapshot, source registry, command palette | Arquitecto BOS | JSON, MD, manifests | BOS |
| printable, guide, workbook, journal | LUMINA Producer | DOCX, PDF, HTML | OPAL + ÆQUITAS |
| quality gate, canon, certification | Auditor ÆQUITAS | audit, dictamen, QC | ÆQUITAS |
| visual coherence, production safety | OPAL Guardrail | visual QA, constraints | OPAL |
| rescue, command lineage, checkpoint | Prometheus Operator | trace, lock, registry | BOS |
| portable prompt, packet, handoff | Metano_IA Packet Architect | schemas, packets | BOS |
| complex orchestration | Adaptive Thinking Extended | masterplan, readiness review | BOS + ÆQUITAS |
| editorial strategy | Director de Artefactos Editoriales | docspec, blueprint, artifact map | LUMINA |

## Locked assertion

```yaml
assertion:
  id: "ASSERT-STYLES-LOCK-001"
  statement: "Styles/Alteregos guide execution, orchestration, voice, review depth and artifact criteria, but they do not become canonical authorities."
  result: "PASS"
```
