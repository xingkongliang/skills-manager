# PROJECT CORE AI GPT BUILDER · v0.9.4

## Patch

Codex GEMA project layer.

## Install over

v0.9.3

## Main decision

Do not merge this as global always-on core. Add it as a conditional project layer activated by Codex GEMA / BOS Critical Apparatus / ÆQUITAS / Anexo A-B / Strong Mapping / pectoral / tribu↔gema queries.

## Upload-ready file

- `UPLOAD_READY_KNOWLEDGE_FILES/CODEX_GEMA_PROJECT_LAYER_EXTRACT_v0_9_4.md`

## Operational status

- Bloque 1: certified/usable with DEC-005 reserve documented.
- DEC-010: valid.
- DEC-005: valid with reserve.
- P1: unlocked.
- Bloque 2: high certainty, pending formal ÆQUITAS dictamen.
- Current CSV: `Codex_Gema_Master_v21_dictamen.csv`.
- Legacy CSV: `Codex_Gema_Master.csv`.

## Key caveat

The Plan Maestro snapshot still describes DEC-005/DEC-010 as blockers, but the later ÆQUITAS Dictamen and Anexo A update that status. Treat the Plan as baseline/history unless the user asks specifically about that snapshot.

## Files included in this package

- `GPT_BUILDER_INSTRUCTIONS_ADDENDUM_v0_9_4.txt`
- `KNOWLEDGE_FILES_POLICY_v0_9_4.json`
- `CODEX_GEMA_PROJECT_LAYER_SCAN_v0_9_4.json`
- `UPLOAD_READY_KNOWLEDGE_FILES/CODEX_GEMA_PROJECT_LAYER_EXTRACT_v0_9_4.md`
- `MANIFEST_PROJECT_CORE_AI_GPT_BUILDER_v0_9_4.json`
