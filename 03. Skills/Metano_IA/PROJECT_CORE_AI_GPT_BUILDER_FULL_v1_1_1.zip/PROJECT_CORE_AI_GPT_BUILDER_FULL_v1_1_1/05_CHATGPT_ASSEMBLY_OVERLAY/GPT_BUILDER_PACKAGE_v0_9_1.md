# GPT Builder Package · Project Core AI · Selah OPAL-BOS Orchestrator v0.9.1

## Patch Status

This v0.9.1 patch resolves the OPAL-BOS / DOCX `SKILL.md` collision and promotes the extracted Style Ops unified core into active GPT Builder knowledge.

## Use in GPT Builder

1. Paste `GPT_BUILDER_INSTRUCTIONS_v0_9_1.txt` into Instructions.
2. Upload files from `UPLOAD_READY_KNOWLEDGE_FILES/` in this order:
   - STYLE_ALTEREGO_ROUTER_LOCKED_v1_2_2.md
   - OPAL_BOS_SKILL_BASE.md
   - STYLE_OPS_CORE_EXTRACT_v1_0.md
   - skills_dependencies_delta.yaml
   - NEUTRAL_PROMPT_SYSTEM_OBSERVABLE_TRACE.md
   - human_enablement_N2.md.docx
3. Add conditional skills only after smoke test:
   - CODEX_AUTOMATION_ENGINEER_STYLE.skill
   - DOCX_SKILL_CONDITIONAL.md

## Build Verdict

```yaml
version: v0.9.1
mode: dry-run_artifact_build
status: GPT_BUILDER_READY_SCOPED
full_native_claimed: false
runtime_truth: blocked_until_installed_and_smoke_tested
```
