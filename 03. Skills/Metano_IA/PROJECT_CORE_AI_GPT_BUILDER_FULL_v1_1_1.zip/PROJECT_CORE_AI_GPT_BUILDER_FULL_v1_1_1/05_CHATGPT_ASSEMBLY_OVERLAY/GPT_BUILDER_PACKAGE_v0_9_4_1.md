# Project Core AI GPT Builder · v0.9.4.1

## Patch
Canonical Claude Bundle Core + AI-Origin Chronological Rehydration.

## What this patch fixes
- Promotes user-approved Claude bundles from reference/lineage to **CORE canonical compiled project bundles**.
- Separates Claude core bundles from ChatGPT assembly overlays.
- Adds chronological inventory sorted by canonical event date.
- Adds origin confidence labels so the GPT can distinguish explicit Claude markers, user-declared Claude bundles, ChatGPT packages, and unknown-author runtime code.

## Install over
`PROJECT_CORE_AI_GPT_BUILDER_v0_9_4`

## Upload-ready knowledge file
`UPLOAD_READY_KNOWLEDGE_FILES/CANONICAL_CORE_AI_ORIGIN_REHYDRATION_v0_9_4_1.md`

## Registry file
`REGISTRY/CANONICAL_CORE_CHRONOLOGICAL_AI_ORIGIN_INVENTORY_v0_9_4_1.json`
