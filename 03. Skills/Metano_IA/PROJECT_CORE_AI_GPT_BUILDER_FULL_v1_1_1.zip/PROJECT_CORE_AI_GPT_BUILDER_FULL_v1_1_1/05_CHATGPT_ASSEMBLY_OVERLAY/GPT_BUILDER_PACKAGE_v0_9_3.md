# Project Core AI · GPT Builder Package v0.9.3

## Patch purpose

v0.9.3 integrates the uploaded architecture packs:

- BOS Architecture Pack v1.0
- ÆQUITAS Architecture Pack v1.0
- IRIDISCENTER Architecture Pack v1.0
- OPAL Architecture Pack v1.0 as pending/reference unless separately verified

## Operational decision

These packs should not be uploaded as a flat pile. They should be used as architecture-layer governance:

- BOS = governance kernel / orchestration backbone
- ÆQUITAS = truth-boundary audit / canon verifier
- IRIDISCENTER = umbrella ecosystem / branch map
- OPAL = production/visual guardrail reference pending full scan

## Install order

1. Keep v0.9.2 installed.
2. Add `GPT_BUILDER_INSTRUCTIONS_ADDENDUM_v0_9_3.txt` beneath the existing instructions.
3. Upload `UPLOAD_READY_KNOWLEDGE_FILES/ARCHITECTURE_PACKS_CORE_EXTRACT_v1_0.md`.
4. Keep original ZIPs as reference/archive, not first-line GPT knowledge unless needed.

## Truth boundary

The scanned architecture packs state that runtime, implementation, deployment, and final commit remain BLOCKED. The GPT must not overclaim these statuses.

## Files generated

- `GPT_BUILDER_INSTRUCTIONS_ADDENDUM_v0_9_3.txt`
- `KNOWLEDGE_FILES_POLICY_v0_9_3.json`
- `UPLOAD_READY_KNOWLEDGE_FILES/ARCHITECTURE_PACKS_CORE_EXTRACT_v1_0.md`
- `ARCHITECTURE_PACKS_SCAN_v0_9_3.json`
- `MANIFEST_PROJECT_CORE_AI_GPT_BUILDER_v0_9_3.json`
