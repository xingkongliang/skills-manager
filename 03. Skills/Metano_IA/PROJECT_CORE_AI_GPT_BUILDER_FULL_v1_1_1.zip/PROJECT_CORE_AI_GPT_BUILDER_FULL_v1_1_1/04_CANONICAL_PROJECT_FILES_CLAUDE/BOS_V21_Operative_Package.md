# Codex Gema BOS — Documento Operativo V2.1
## Sistema Iridiscenter · BOS Critical Apparatus
**Versión:** 2.1 | **Fecha:** 2026-03-28 | **Estado:** draft — pendiente persistencia final

---

## CHANGELOG V2.1

| Bloque añadido | Descripción | Estado |
|---|---|---|
| VALIDACIÓN SISTÉMICA | Preflight automático de coherencia entre Codex, Metabase e Investigaciones | activo |
| MEMORIA DEL SISTEMA | Hook onComplete que upserta metabase y registra hipótesis | activo |
| GENERACIÓN VISUAL | Descriptores UI + image-gen por gema y pectoral | activo |
| Codex_Gema_Master.csv | Plantilla con 12 filas completas + schema validado | entregado |
| Widget JSON V2.1 | Config actualizado con métricas ÆQUITAS y estado por tribu | entregado |

---

## BLOQUE 0 — QUALITY GATE (sin cambios de V2.0)

```
/QUALITY_GATE_ACTIVATE
  nivel_rigor: POSDOCTORAL
  citacion: APA_7_estricto
  metodologia: PRISMA_2020
  lengua: español_académico_formal
  lexicon: Strong + BDB/HALOT (hebreo) · BDAG (griego)
  orientacion: cristocéntrica_transdisciplinar
  densidad_analitica: máxima
  prohibido: afirmaciones_sin_evidencia · citas_no_verificadas
```

---

## BLOQUE V2.1-A — VALIDACIÓN SISTÉMICA

Ejecutar como preflight antes de cualquier investigación o persistencia.

```json
{
  "task": "preflight",
  "scope": "sample_by_tribe",
  "sample_size": 2,
  "params": {
    "check_mapping": true,
    "validate_lexemes": true,
    "detect_semantic_conflicts": true,
    "reconciliation_priority": ["Metabase", "Codex", "Investigacion"]
  },
  "output_schema": {
    "meta": {"ts": "ISO", "mode": "dry-run", "v": "2.1"},
    "summary": {"checks_passed": "n", "conflicts": "n"},
    "conflicts": [{"row": "x", "issue": "...", "suggestion": "..."}],
    "batch_plan": {"n": "batches", "size": "per_batch"},
    "assumptions": ["..."]
  }
}
```

**Checks obligatorios (QC-01 a QC-10):**

| ID | Check | Criterio de aceptación |
|---|---|---|
| QC-01 | Schema CSV válido | Todas las columnas presentes; tipos coherentes |
| QC-02 | No duplicados en batch | uuid y gem_id únicos por fila |
| QC-03 | Mappings completos | 12/12 filas con gem_id + tribu_id asignados |
| QC-04 | Lemmas sin ambigüedad | >90% resueltos; restantes listados explícitamente |
| QC-05 | Changelog generado | tag vX.X presente en documento operativo |
| QC-06 | Artifact paths retornados | array artifact_paths no vacío |
| QC-07 | Batch plan aprobado | n_batches y size definidos y justificados |
| QC-08 | Image descriptors generados | ≥3 descriptores en registro |
| QC-09 | Tests de script (pseudocódigo) | Idempotencia verificada en simulación |
| QC-10 | Plan de rollback definido | 5 pasos documentados con responsables |

---

## BLOQUE V2.1-B — MEMORIA DEL SISTEMA

Hook que se ejecuta al completar cada investigación (onComplete).

```yaml
memory_hook:
  trigger: investigation_complete
  actions:
    - type: upsert
      target: Codex_Gema_Master.csv
      fields: [inv_id, estado_inv, estado_aequitas, nivel_tension, fecha_version]
      key: tribu_id
      mode: update_if_exists
    - type: upsert
      target: STRONG_MAPPING_expanded.csv
      fields: [strong_id, estado_validacion, validado_por, fecha_validacion, lexicon_page]
      key: strong_id
      mode: update_if_exists
    - type: append
      target: hipotesis_log.json
      fields:
        - hypothesis_text: "{{hallazgo_clave}}"
        - source: "{{inv_id}}"
        - confidence: "{{nivel_certeza}}"
        - date: "{{fecha}}"
        - status: draft
    - type: append
      target: CHANGELOG.md
      fields:
        - entry: "{{inv_id}} v{{version}} completada — {{fecha}} — {{revisor}}"
  post_actions:
    - validate: run_QC_01_to_10
    - notify: "INV {{inv_id}} registrada en metabase"
    - update_engine: Codex_GEMA_Engine.html  # re-renderizar estado gemas
```

**Campos a actualizar por investigación completada:**

```
Codex_Gema_Master.csv:
  → inv_id          : "INV-XXXX"
  → estado_inv      : "v1.0"
  → estado_aequitas : "en_proceso" | "validada" | "certificada"
  → nivel_tension   : "bajo" | "medio" | "alto"
  → fecha_version   : "YYYY-MM-DD"

ACTA_COBERTURA.md:
  → nueva entrada por cada DEC-XXX resuelta o abierta

STRONG_MAPPING_expanded.csv:
  → estado_validacion actualizado para cada término de la investigación
```

---

## BLOQUE V2.1-C — GENERACIÓN VISUAL

Disparar solo tras aprobación del dry-run (QC-01 a QC-10 = PASS).

```json
{
  "visual_outputs": {
    "pectoral_map": {
      "type": "interactive_dashboard",
      "source": "Codex_Gema_Master.csv",
      "fields_displayed": ["tribu_nombre", "gema_label", "color_hex", "estado_aequitas", "inv_id"],
      "layout": "grid_4x3",
      "interactivity": ["click_open_investigation", "hover_show_strong_id", "filter_by_estado"],
      "refresh": "on_csv_update"
    },
    "progress_ring": {
      "type": "circular_progress",
      "value": "count(estado_inv == 'v1.0') / 12",
      "label": "investigaciones completadas",
      "color_complete": "#2E7D32",
      "color_pending": "#3A4A5E"
    },
    "tension_graph": {
      "type": "node_graph",
      "nodes": "tribes",
      "edges": "canonical_relationships",
      "color_encoding": "nivel_tension",
      "highlight": ["TRB-04", "TRB-11"]
    }
  },
  "image_gen_batch": {
    "status": "DEFERRED — awaiting dry-run OK",
    "descriptors_ready": 3,
    "approval_required": true,
    "batch_on_approve": "generate_all_3_in_single_call"
  }
}
```

---

## BLOQUE V2.1-D — COMANDOS DE SESIÓN

```
@INVESTIGAR  → Ejecuta F0–F9 completo + onComplete memory hook
@INFORME     → Solo informe académico (sin metabase)
@METABASE    → Solo JSON/CSV para metabase BOS
@QC          → Ejecuta QC-01 a QC-10 en modo dry-run
@AEQUITAS    → Emite dictamen sobre DEC activa
@PREFLIGHT   → Ejecuta VALIDACIÓN SISTÉMICA sobre muestra
@SYNC        → Simula sync Metabase ↔ Codex ↔ Investigaciones
@VISUAL      → Genera descriptores y activa GENERACIÓN VISUAL
@STATUS      → Reporta estado actual del Codex (JSON compacto)
```

---

## PROMPT COMPACTO — EJECUCIÓN RÁPIDA (bajo tokens)

```
Task: preflight sample 2 per tribe; return compact JSON only; 
suggest batch plan; use conservative assumptions if missing;
schema: {meta, summary{checks_passed,conflicts}, 
conflicts[{row,issue,suggestion}], batch_plan{n,size}, assumptions}.
```

---

## SCRIPT PSEUDOCÓDIGO — SYNC CRON + DRY-RUN

```pseudocode
CRON: every 6 hours → run BOS_SYNC_DRYRUN

PROCEDURE BOS_SYNC_DRYRUN:
  1. LOAD Codex_Gema_Master.csv → codex_state
  2. LOAD STRONG_MAPPING_expanded.csv → lexicon_state
  3. LOAD /outputs/*.json WHERE type=REGISTRO_INFORME → inv_state
  
  4. FOR each tribu IN codex_state:
       a. CHECK: tribu.inv_id EXISTS in inv_state → flag missing
       b. CHECK: tribu.estado_inv MATCHES inv_state[inv_id].estado → flag mismatch
       c. CHECK: tribu.strong_ex28 EXISTS in lexicon_state → flag unknown_strong
       d. CHECK: tribu.nivel_tension MATCHES inv_state[inv_id].nivel_tension → flag tension_drift
  
  5. GENERATE delta_report:
       - rows_ok: count(no flags)
       - rows_warn: count(non-blocking flags)
       - rows_conflict: count(blocking flags)
  
  6. IF delta_report.rows_conflict == 0:
       → mark: "READY_FOR_PERSIST"
       → notify: "Sync clean — proceed with batch upsert"
  7. ELSE:
       → mark: "BLOCKED"
       → output: conflict list with suggestions
       → DO NOT write to metabase
  
  8. APPEND to observations_log.json:
       {run_id, ts, scope, summary_hash, top_conflicts}
  
  9. IF mode == "persist" AND approval == true:
       → UPSERT Codex_Gema_Master.csv (batch by tribu, idempotent)
       → UPSERT STRONG_MAPPING_expanded.csv (only changed rows)
       → TAG document: v2.1
       → APPEND CHANGELOG.md

END PROCEDURE
```

---

## WIDGET CONFIG V2.1

```json
{
  "id": "codex-pectoral-v21",
  "title": "Codex GEMA — Control Center",
  "version": "2.1",
  "metrics": [
    {"k": "progreso", "t": "pct", "label": "Investigaciones completadas", "value": "2/12"},
    {"k": "aequitas_pending", "t": "count", "label": "Pendientes ÆQUITAS", "severity": {"warn": 3, "critical": 6}},
    {"k": "tensiones_abiertas", "t": "count", "label": "Tensiones documentadas", "value": 5},
    {"k": "lexemas_validados", "t": "count", "label": "Lexemas Strong validados", "value": 23},
    {"k": "tribu_activa", "t": "string", "label": "Investigación activa", "value": "INV-0006 Judá/Selah"}
  ],
  "actions": [
    {"id": "open_gema", "type": "navigate", "label": "Abrir gema", "target": "/gema/{{gem_id}}"},
    {"id": "run_investigation", "type": "invoke_prompt", "label": "Nueva investigación", "promptId": "PROMPT_MAESTRO_BOS_V21"},
    {"id": "run_preflight", "type": "invoke_prompt", "label": "Ejecutar preflight", "promptId": "BOS_PREFLIGHT"},
    {"id": "run_aequitas", "type": "invoke_prompt", "label": "Dictamen ÆQUITAS", "promptId": "BOS_AEQUITAS"}
  ],
  "refresh": "cron:0 */6 * * *",
  "data_source": "Codex_Gema_Master.csv",
  "last_sync": "2026-03-28T20:00:00Z",
  "next_action": "Resolver DEC-005 + DEC-010 → producir Anexo A → P1"
}
```

---

## ESTADO ACTUAL DEL SISTEMA (snapshot v2.1)

```json
{
  "meta": {"ts": "2026-03-28", "mode": "snapshot", "v": "2.1"},
  "investigations": {
    "total": 12,
    "complete": 2,
    "active": 1,
    "pending": 9,
    "complete_ids": ["INV-0005", "INV-0006"],
    "active_ids": [],
    "next_queue": ["INV-Leví", "INV-Benjamín", "INV-Rubén", "INV-Simeón"]
  },
  "aequitas": {
    "certified": 0,
    "valid": 0,
    "in_process": 2,
    "pending": 10,
    "blocked_decisions": ["DEC-005", "DEC-008", "DEC-010"]
  },
  "lexicon": {
    "total_entries": 115,
    "validated": 48,
    "pending": 62,
    "tension": 5
  },
  "next_critical_action": "Producir Anexo A del Codex GEMA con INV-0005 + INV-0006 → solicitar dictamen ÆQUITAS sobre DEC-005 y DEC-010 → desbloquear P1"
}
```
