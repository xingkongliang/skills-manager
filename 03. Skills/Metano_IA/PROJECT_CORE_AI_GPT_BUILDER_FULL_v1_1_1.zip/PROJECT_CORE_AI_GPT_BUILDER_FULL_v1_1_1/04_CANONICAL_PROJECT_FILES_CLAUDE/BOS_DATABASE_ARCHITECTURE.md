# Arquitectura de Metabase de Datos
## BOS Critical Apparatus — Sistema Iridiscenter
### Versión 1.0 · Nivel posdoctoral · APA 7 · PRISMA 2020

---

## 1. Principios de diseño

La metabase de datos del BOS Critical Apparatus sigue cuatro principios de arquitectura:

**Trazabilidad total.** Cada afirmación del sistema puede rastrearse hasta su fuente primaria (texto bíblico + edición crítica + lexicón). Ningún dato existe sin referencia verificable.

**Separación de estados.** Los datos tienen estado explícito: `pending`, `in_review`, `validated`, `rejected`. Nada pasa a estado `validated` sin registro de quién validó y cuándo.

**Actualización incremental.** La metabase se diseña para incorporar nuevos libros, nuevas decisiones y nuevas fuentes sin rediseñar el esquema. Las tablas son aditivas, no destructivas.

**Herencia sistémica.** Los registros de la metabase son los insumos directos para los dictámenes de ÆQUITAS y para la herencia de LUMINA. La metabase es el single source of truth del BOS Critical Apparatus.

---

## 2. Esquema relacional

```
┌─────────────────────────────────────────────────────────────────────────┐
│                      BOS_CRITICAL_APPARATUS_DB                          │
└─────────────────────────────────────────────────────────────────────────┘

TABLA CENTRAL: INVESTIGATIONS
  id                    CHAR(8) PRIMARY KEY       -- formato: INV-XXXX
  libro                 VARCHAR(60) NOT NULL
  referencia_biblica    VARCHAR(100) NOT NULL      -- e.g. "Rut 1:1–4:22"
  corpus_canonico       ENUM('TM','LXX','NT_GK','deuterocanónico','mixto')
  pregunta_principal    TEXT NOT NULL
  fecha_inicio          DATE NOT NULL
  fecha_version_1       DATE
  estado                ENUM('borrador','en_revision','v1.0','archivado')
  version_acta          VARCHAR(10)                -- e.g. "v0.2"
  revisor_principal     VARCHAR(100)
  tribu_asociada        VARCHAR(50)               -- FK → TRIBES
  gema_candidata        VARCHAR(50)               -- FK → GEMS
  nivel_tension         ENUM('bajo','medio','alto')
  rama_bos              SMALLINT                  -- FK → BOS_BRANCHES
  notas_aequitas        TEXT

TABLA: METHODOLOGIES_APPLIED  (relación N:M con INVESTIGATIONS)
  id                    SERIAL PRIMARY KEY
  investigation_id      CHAR(8) FK → INVESTIGATIONS
  method_code           VARCHAR(50)               -- FK → METHODS_CATALOG
  justification         TEXT
  resultado_clave       TEXT

TABLA: METHODS_CATALOG
  code                  VARCHAR(50) PRIMARY KEY
  categoria             ENUM('textual','historico-critico','literario',
                             'hermeneutico','revision-sistematica')
  nombre_completo       VARCHAR(200)
  descripcion           TEXT
  fuentes_referencia    TEXT[]                    -- autores clave del método
  activo                BOOLEAN DEFAULT TRUE

TABLA: LEXICAL_ENTRIES
  id                    SERIAL PRIMARY KEY
  strong_id             VARCHAR(10) NOT NULL      -- e.g. "H2617", "G4102"
  lemma                 VARCHAR(100) NOT NULL     -- en caracteres originales
  transliteration       VARCHAR(100) NOT NULL
  idioma                ENUM('hebreo','griego','arameo')
  lexicon_source        ENUM('BDB','HALOT','BDAG','TDNT','NIDNTT','TWOT','otro')
  lexicon_page          VARCHAR(20)               -- página o entrada exacta
  lexicon_entry_id      VARCHAR(30)               -- número de entrada si aplica
  significado_basico    TEXT NOT NULL
  significado_contextual TEXT
  glosa_sistema         TEXT                      -- interpretación Iridiscenter
  investigation_id      CHAR(8) FK → INVESTIGATIONS
  versiculo             VARCHAR(30)               -- e.g. "Rut 1:8"
  estado_validacion     ENUM('pending','validated','rejected','tension')
  validado_por          VARCHAR(100)
  fecha_validacion      DATE
  notas                 TEXT
  tension_documentada   TEXT                      -- si estado = 'tension'

TABLA: SOURCES
  id                    CHAR(10) PRIMARY KEY      -- formato: SRC-XXXXXX
  tipo                  ENUM('texto_biblico','lexico','comentario',
                             'articulo_peer','monografia','tesis',
                             'recurso_digital','otro')
  autor_apellido        VARCHAR(200)
  autor_nombre          VARCHAR(200)
  year                  SMALLINT
  titulo                TEXT NOT NULL
  subtitulo             TEXT
  edicion               VARCHAR(20)
  editorial             VARCHAR(200)
  ciudad                VARCHAR(100)
  doi                   VARCHAR(200)
  url                   VARCHAR(500)
  isbn_issn             VARCHAR(30)
  idioma                VARCHAR(20)
  paginas_totales       SMALLINT
  pertinencia_libros    VARCHAR[]                 -- libros bíblicos cubiertos
  estado_incorporacion  ENUM('identificada','incorporada','validada','excluida')
  motivo_exclusion      TEXT
  fecha_incorporacion   DATE
  incorporado_por       VARCHAR(100)
  nota_apa7             TEXT                      -- referencia formateada APA 7

TABLA: DECISIONS_REGISTER  (Acta de Cobertura)
  id                    CHAR(10) PRIMARY KEY      -- formato: DEC-XXXXXX
  investigation_id      CHAR(8) FK → INVESTIGATIONS
  tipo_decision         ENUM('textual','lexicografica','metodologica',
                             'hermeneutica','asignacion_tribu_gema',
                             'estructural_sistema')
  descripcion           TEXT NOT NULL
  opciones_consideradas JSONB                     -- [{opcion, justificacion}]
  opcion_adoptada       TEXT
  criterio_resolucion   TEXT
  fuentes_soporte       TEXT[]                    -- ids de SOURCES
  estado                ENUM('abierta','en_proceso','resuelta','pendiente_aequitas')
  nivel_tension         ENUM('bajo','medio','alto')
  validado_por          VARCHAR(100)
  fecha_apertura        DATE
  fecha_cierre          DATE
  version_acta          VARCHAR(10)
  nota_aequitas         TEXT

TABLA: SYNTHESIS_RESULTS
  id                    SERIAL PRIMARY KEY
  investigation_id      CHAR(8) FK → INVESTIGATIONS
  categoria             VARCHAR(100) NOT NULL
  palabras_clave        TEXT[]
  referencias_biblicas  TEXT[]
  lexemas_clave         TEXT[]                    -- ids de LEXICAL_ENTRIES
  interpretacion_sistemica TEXT
  aplicacion_intergeneracional TEXT
  nivel_certeza         ENUM('alto','medio','bajo','tension')
  fecha_registro        DATE
  notas                 TEXT

TABLA: TRIBES  (catálogo canónico)
  id                    CHAR(6) PRIMARY KEY       -- formato: TRB-XX
  nombre                VARCHAR(50) NOT NULL
  nombre_hebreo         VARCHAR(50)
  numero_pectoral       SMALLINT                  -- posición en Éx 28
  piedra_ex28_strong    VARCHAR(10) FK → LEXICAL_ENTRIES
  piedra_ap21_bdag      VARCHAR(10) FK → LEXICAL_ENTRIES
  cualidad_gn49         TEXT
  cualidad_dt33         TEXT
  gema_candidata        VARCHAR(50) FK → GEMS
  nivel_tension_asignacion ENUM('bajo','medio','alto')
  estado_asignacion     ENUM('candidatura','en_estudio','validado_aequitas')
  rama_bos_asociada     SMALLINT FK → BOS_BRANCHES
  notas                 TEXT

TABLA: GEMS  (catálogo canónico Iridiscenter)
  id                    CHAR(6) PRIMARY KEY       -- formato: GEM-XX
  nombre                VARCHAR(50) NOT NULL
  numero_tribu          SMALLINT
  hex_color             CHAR(7)
  cualidad_primaria     VARCHAR(100)
  cualidad_secundaria   VARCHAR(100)
  arquetipo             VARCHAR(100)
  funcion_marca         TEXT
  aleph_variacion       VARCHAR(50)
  tribu_asignada        VARCHAR(50) FK → TRIBES
  estado                ENUM('candidatura','establecida','certificada')
  version_codex         VARCHAR(10)

TABLA: BOS_BRANCHES
  id                    SMALLINT PRIMARY KEY
  nombre                VARCHAR(100)
  descripcion           TEXT
  estado_produccion     ENUM('activa','planificada','completada','pausada')
  investigations_ids    CHAR(8)[]                 -- FK array → INVESTIGATIONS

TABLA: CHANGELOG
  id                    SERIAL PRIMARY KEY
  tabla_afectada        VARCHAR(50)
  registro_id           VARCHAR(20)
  tipo_cambio           ENUM('insert','update','delete','version_change')
  campo_modificado      VARCHAR(100)
  valor_anterior        TEXT
  valor_nuevo           TEXT
  modificado_por        VARCHAR(100)
  fecha_modificacion    TIMESTAMP DEFAULT NOW()
  version_resultado     VARCHAR(10)
  nota                  TEXT
```

---

## 3. Índices y consultas frecuentes

```sql
-- Índice por estado de validación léxica (consulta más frecuente)
CREATE INDEX idx_lex_estado ON LEXICAL_ENTRIES(estado_validacion);
CREATE INDEX idx_lex_strong ON LEXICAL_ENTRIES(strong_id);
CREATE INDEX idx_lex_investigation ON LEXICAL_ENTRIES(investigation_id);

-- Índice por tensión en decisiones
CREATE INDEX idx_dec_tension ON DECISIONS_REGISTER(nivel_tension, estado);

-- Vista: todas las entradas léxicas en tensión con su decisión asociada
CREATE VIEW v_lexical_tensions AS
  SELECT l.strong_id, l.lemma, l.transliteration, l.tension_documentada,
         d.descripcion AS decision_pendiente, d.estado AS estado_decision,
         t.nombre AS tribu, g.nombre AS gema_candidata
  FROM LEXICAL_ENTRIES l
  LEFT JOIN DECISIONS_REGISTER d ON l.investigation_id = d.investigation_id
  LEFT JOIN TRIBES t ON t.piedra_ex28_strong = l.strong_id
  LEFT JOIN GEMS g ON t.gema_candidata = g.id
  WHERE l.estado_validacion = 'tension'
  ORDER BY l.strong_id;

-- Vista: estado completo del Anexo A (asignación tribu ↔ gema)
CREATE VIEW v_annexa_status AS
  SELECT t.numero_pectoral, t.nombre AS tribu,
         t.nombre_hebreo, l_ex.lemma AS piedra_ex28,
         l_ex.strong_id, l_ex.significado_basico,
         l_ap.lemma AS piedra_ap21,
         g.nombre AS gema_irid, g.hex_color,
         t.nivel_tension_asignacion,
         t.estado_asignacion
  FROM TRIBES t
  LEFT JOIN LEXICAL_ENTRIES l_ex ON t.piedra_ex28_strong = l_ex.strong_id
  LEFT JOIN LEXICAL_ENTRIES l_ap ON t.piedra_ap21_bdag = l_ap.strong_id
  LEFT JOIN GEMS g ON t.gema_candidata = g.id
  ORDER BY t.numero_pectoral;
```

---

## 4. Flujo de actualización incremental

Cada nuevo libro procesado sigue este protocolo de incorporación:

```
NUEVO_LIBRO → INVESTIGATIONS.insert()
            → METHODOLOGIES_APPLIED.insert() [métodos seleccionados]
            → LEXICAL_ENTRIES.insert() [todos los términos clave]
            → SOURCES.insert() [fuentes nuevas usadas]
            → SYNTHESIS_RESULTS.insert() [tabla de síntesis]
            → DECISIONS_REGISTER.insert() [decisiones abiertas]
            → TRIBES.update() [si afecta asignación]
            → GEMS.update() [si cambia estado de gema]
            → CHANGELOG.insert() [registro automático]
            → AEQUITAS_REVIEW.trigger() [si nivel_tension = 'alto']
```

---

## 5. Convenciones de nomenclatura

| Prefijo | Entidad | Ejemplo |
|---|---|---|
| INV- | Investigación | INV-0001 |
| SRC- | Fuente | SRC-001234 |
| DEC- | Decisión | DEC-000001 |
| TRB- | Tribu | TRB-04 |
| GEM- | Gema | GEM-04 |
| LEX- | Entrada léxica | LEX-H2617 |
| CHG- | Cambio en changelog | CHG-000001 |

---

## 6. Política de versiones y Acta de Cobertura

- `v0.1` — registro inicial, sin validación
- `v0.2` — tras integración Strong/BDB/HALOT
- `v0.3` — tras cotejo LXX/TM
- `v1.0` — validado por ÆQUITAS, read-only salvo nueva entrada en Acta

Todo campo que cambia de estado a `validated` o `v1.0` genera automáticamente
un registro en `CHANGELOG` con `version_resultado = 'v1.0'` y requiere
el campo `validado_por` no nulo.
