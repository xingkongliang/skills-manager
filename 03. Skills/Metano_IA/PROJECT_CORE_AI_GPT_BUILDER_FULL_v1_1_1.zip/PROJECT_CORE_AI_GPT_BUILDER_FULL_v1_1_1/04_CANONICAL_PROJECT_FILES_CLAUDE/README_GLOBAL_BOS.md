# README Global — Proyecto BOS Critical Apparatus
## Análisis Exhaustivo e Investigaciones Bíblicas

**Versión:** 1.0  
**Fecha:** Marzo 2026  
**Responsable:** Raquel Alejandra Barrón  
**Metodología base:** PRISMA 2020 · APA 7ª edición · Análisis lexicográfico Strong / BDB / HALOT / BDAG

---

## 1. Propósito del proyecto

El proyecto **BOS Critical Apparatus** constituye el aparato crítico de referencia del metasistema Iridiscenter para el estudio sistemático de textos bíblicos con relevancia directa en la asignación tribu-gema y en las ramas de producción activas. Cada informe es simultáneamente un documento académico autónomo y un artefacto del sistema: su rigor lexicográfico y metodológico garantiza que las decisiones de asignación puedan ser auditadas por ÆQUITAS y heredadas por LUMINA sin pérdida de coherencia semántica.

El corpus activo comprende actualmente los libros de **Ester, Rut, Job y la Epístola de Santiago**. Los libros de **José** (Génesis 37–50) y **Judá/David/Salmos** (con énfasis en el concepto Selah) constituyen el próximo lote de producción, directamente vinculados a la decisión P2 del Codex GEMA: la asignación canónica tribu bíblica ↔ gema.

---

## 2. Estructura de carpetas del proyecto

```
BOS_Critical_Apparatus/
├── README_GLOBAL_BOS.md          ← este archivo
├── plantilla_APA.docx            ← plantilla de estilos para generación DOCX
├── STRONG_MAPPING_expanded.csv   ← mapa lexicográfico Strong → BDB/HALOT/BDAG
├── ACTA_COBERTURA.md             ← registro de decisiones textuales
├── CHANGELOG.md                  ← historial de versiones
├── GLOSSARY.md                   ← glosario canónico del sistema
│
├── SOURCES/
│   ├── METADATA_INDEX.md         ← índice de fuentes primarias y secundarias
│   ├── ORIGINALS/                ← copias originales sin modificar
│   └── EXTRACTS/                 ← excerpts relevantes por fuente
│
├── Ester/
│   ├── README_Ester.md
│   ├── 01_Documentos/
│   ├── 02_Recursos/
│   └── 03_Metadatos/
│
├── Rut/
│   ├── README_Rut.md
│   ├── 01_Documentos/
│   ├── 02_Recursos/
│   └── 03_Metadatos/
│
├── Job/
│   ├── README_Job.md
│   ├── 01_Documentos/
│   ├── 02_Recursos/
│   └── 03_Metadatos/
│
├── Santiago/
│   ├── README_Santiago.md
│   ├── 01_Documentos/
│   ├── 02_Recursos/
│   └── 03_Metadatos/
│
└── [En preparación]
    ├── José/
    └── Judá_David_Selah/
```

---

## 3. Flujo de trabajo

### 3.1 Recepción de fuentes

Toda fuente nueva se coloca en `SOURCES/ORIGINALS/` sin modificar, con nomenclatura estricta:

```
SOURCE_<Autor>_<Año>_<Abreviatura>.<ext>
```

Por ejemplo: `SOURCE_Strong_1890_Concordance.pdf`, `SOURCE_BDB_1906_Hebrew_Lexicon.pdf`.

Los metadatos mínimos de cada fuente — título, autor/edición, año, tipo, idioma, páginas o pasajes, identificador (ISBN/DOI/URL) — se registran en `SOURCES/METADATA_INDEX.md` en el momento de la incorporación.

### 3.2 Extracción y registro

Los pasajes relevantes extraídos de cada fuente se depositan en `SOURCES/EXTRACTS/<fuente>_excerpts.md`. El inventario de fuentes se mantiene en `SOURCES/INDEX.csv` con las columnas: id, título abreviado, cobertura temática, estado de validación y notas.

### 3.3 Mapeo lexicográfico

El archivo `STRONG_MAPPING_expanded.csv` es el instrumento de trabajo léxico del proyecto. Para cada entrada el proceso de validación es el siguiente: identificar el número Strong del término en el texto hebreo o griego; localizar la entrada correspondiente en BDB, HALOT o BDAG; registrar la referencia exacta (página y entrada); marcar el estado como `pending`, `validated` o `rejected`; documentar en `GLOSSARY/ISSUES.md` cualquier discrepancia entre Strong y los léxicos críticos.

### 3.4 Generación de documentos

Los informes se generan desde archivos Markdown mediante el siguiente flujo:

```bash
# Generar DOCX con estilos APA
pandoc "03_Análisis_..._<LIBRO>.md" \
  -o "01_Análisis_..._<LIBRO>.docx" \
  --reference-doc=plantilla_APA.docx

# Generar PDF
pandoc "03_Análisis_..._<LIBRO>.md" \
  -o "02_Análisis_..._<LIBRO>.pdf" \
  --pdf-engine=xelatex

# Comprimir paquete (macOS / Linux)
zip -r "Análisis exhaustivo e investigaciones Bíblicas – Libro de <LIBRO>.zip" \
  "Análisis exhaustivo e investigaciones Bíblicas – Libro de <LIBRO>"
```

### 3.5 Revisión y Acta de Cobertura

Toda decisión textual mayor — adopción de una lectura frente a variantes, interpretación de un término en contexto, asignación lexicográfica — se registra en `ACTA_COBERTURA.md` con la siguiente estructura por entrada:

| Campo | Descripción |
|---|---|
| Perícopa | Referencia bíblica exacta |
| Lectura adoptada | Texto o interpretación seleccionada |
| Fuente | Identificador de la fuente primaria |
| Justificación | Razón académica y sistémica |
| Responsable | Nombre del revisor |
| Fecha | YYYY-MM-DD |
| Versión del Acta | v0.x / v1.0 |

---

## 4. Versionado

El proyecto sigue la convención `v<mayor>.<menor>`:

- `v0.1` — borrador con estructura inicial.
- `v0.2` — tras integración del mapeo lexicográfico Strong.
- `v0.3` — tras revisión de variantes textuales LXX/MT.
- `v1.0` — documento aprobado, listo para distribución y herencia sistémica.

Todo cambio se registra en `CHANGELOG.md` con fecha, responsable y resumen de la modificación. Ningún documento pasa a estado `v1.0` sin entrada en el Acta de Cobertura y validación de ÆQUITAS.

---

## 5. Roles y responsabilidades

| Rol | Función |
|---|---|
| Coordinadora de Proyecto | Versionado del Acta, entregables finales, validación ÆQUITAS |
| Editora Textual | Ensamblado MD → DOCX, revisión de estilo APA |
| Equipo Léxico | Validación Strong ↔ BDB / HALOT / BDAG |
| Revisora Académica | Revisión teológica y metodológica final |

---

## 6. Relación con el Codex GEMA

Los informes de este proyecto son los documentos de base que ÆQUITAS y LUMINA utilizan para resolver la decisión P2 del Codex GEMA: la asignación canónica tribu bíblica ↔ gema. El flujo es el siguiente:

1. Los textos de Éxodo 28:17-20 y Apocalipsis 21:19-20 son analizados mediante la Concordancia Strong y el BDB para identificar el nombre hebreo y griego exacto de cada piedra en los cimientos y en el pectoral del sumo sacerdote.
2. Las cualidades espirituales y narrativas de cada tribu se extraen de Génesis 49 y Deuteronomio 33 usando las cadenas temáticas de la Biblia Thompson.
3. El cruce entre el perfil mineralógico de cada piedra y el perfil tribal produce la propuesta de asignación.
4. ÆQUITAS emite dictamen sobre cada asignación y la incorpora al Codex como Anexo A.

Los libros de Ester, Rut, Job y Santiago son estudios de personajes y temas que pertenecen a tribus específicas dentro del sistema. Los próximos libros — José y Judá/David — son directamente los textos primarios para resolver P2.

---

## 7. Buenas prácticas

Las fuentes originales en `SOURCES/ORIGINALS/` no se modifican bajo ninguna circunstancia. Toda interpretación se realiza sobre copias en `EXTRACTS/`. Las referencias lexicográficas se citan con página y entrada exacta una vez validadas; las referencias orientativas del CSV se marcan como `pending` hasta su verificación. Los archivos de producción se respaldan con cada versión mayor del Acta. Los documentos en estado `v1.0` son read-only dentro del sistema, salvo nueva entrada en el Acta de Cobertura.

---

*Este documento es de Nivel 1 — Documentation Layer (L1-D) del metasistema Iridiscenter. No ejerce autoridad de gobernanza. Orienta y reduce carga cognitiva sin modificar las leyes del Nivel 0.*
