# CODEX GEMA PROJECT LAYER EXTRACT v0.9.4

## Role

This file is a project-domain knowledge layer for Project Core AI · Selah OPAL-BOS Orchestrator.

It should activate when the user mentions:

- Codex GEMA
- BOS Critical Apparatus
- ÆQUITAS Dictamen
- Anexo A / Anexo B
- Codex_Gema_Master
- Strong Mapping
- Pectoral / tribu↔gema
- Iridiscenter Metasystem plan
- BOS V2.1 / V3 project state

## Placement

```yaml
placement: conditional_project_core
not_global_core: true
reason: "This is high-value domain state for Codex GEMA, but should not overload every response of the general Project Core AI."
```

## Current status reconciliation

```yaml
codex_gema_status_v0_9_4:
  legacy_plan_snapshot:
    source: "Plan_Maestro_Metasistema.docx"
    status: "Fase IV active; DEC-005/DEC-010 formerly blocking"
    note: "Use as historical/plan baseline, not latest state if newer dictamen is present."

  dictamen_bloque_1:
    source: "AEQUITAS_Dictamen_Bloque1.json"
    date: "2026-03-30"
    DEC_010_Juda_Garnet: "VALIDO"
    DEC_005_Jose_Alexandrite: "VALIDO_CON_RESERVA"
    critical_update:
      - "José/Alexandrite is not direct pectoral TM lexicographic equivalence."
      - "José direct pectoral record should include H7718 shoham/onyx."
      - "Alexandrite is preserved as systemic/archetypal Codex GEMA decision."
      - "H8658 tarshish should be tracked for Aser."

  anexo_A:
    source: "Anexo_A_Codex_GEMA.html"
    status: "Bloque 1 certificado; P1 desbloqueado"

  anexo_B:
    source: "Anexo_B_Codex_GEMA.pdf"
    status: "Bloque 2 high certainty; Leví/Emerald + Benjamín/Peridot ready for formal ÆQUITAS"
    inv_completed: "4/12 per Anexo B"

  csv_status:
    source_current: "Codex_Gema_Master_v21_dictamen.csv"
    rows: 12
    aequitas_counts:
      valido: 1
      valido_reserva: 1
      pendiente: 10
    inv_counts:
      v1_0: 2
      pendiente: 10
    note: "CSV v21 has Bloque 1 applied; it does not yet fully reflect Anexo B's 4/12 investigation state in inv_id fields."

  recommended_operational_truth:
    - "Bloque 1: usable/certified with DEC-005 reserve documented."
    - "P1: unlocked according to Anexo A and ÆQUITAS Auditor UI."
    - "Bloque 2: high certainty / ready for formal dictamen, not full formal certification unless a formal Dictamen Bloque 2 file is added."
    - "Do not treat older preflight blocker as latest truth after AEQUITAS_Dictamen_Bloque1."
```

## File classification

```yaml
active_project_layer:
  - Codex_Gema_Master_v21_dictamen.csv
  - STRONG_MAPPING_expanded.csv
  - AEQUITAS_Dictamen_Bloque1.json
  - BOS_V21_Operative_Package.md
  - BOS_Preflight_DryRun_v21.json
  - BOS Skills Artifacts v2.json
  - Plan_Maestro_Metasistema.docx
  - Anexo_A_Codex_GEMA.html
  - Anexo_B_Codex_GEMA.pdf
  - Atlas_Maestro_Metasistema.html
  - Codex_GEMA_Engine_V21.html

lineage_reference:
  - Codex_Gema_Master.csv
  - Codex_GEMA_Engine.html

dashboard_reference:
  - AEQUITAS_Auditor_Skill.html

conditional_runtime_code_reference:
  - bos_opal_full_build_pro_production_system_v_5.py
```

## Activation behavior

When this layer activates:

1. Use latest evidence hierarchy:
   - formal dictamen / certified annex
   - current CSV v21-dictamen
   - operative package
   - preflight dry-run
   - plan master
   - dashboard HTMLs
2. Prefer Anexo A + AEQUITAS_Dictamen_Bloque1 over older Plan Maestro blocker statements.
3. Keep Bloque 2 as "alta certeza / pendiente formal" unless formal Dictamen Bloque 2 is available.
4. For any write/persist request, use BOS dry-run first.
5. Do not execute the Python production system unless explicitly instructed and environment keys/dependencies are available.
6. Maintain source vs derivative boundaries.
7. Keep user-facing explanation human and brief; registry detail in background.

## Updated smoke tests

```text
Activa Codex GEMA project layer y dame estado actual reconciliado.

Revisa si DEC-005 y DEC-010 siguen bloqueando o ya cambiaron por dictamen.

Haz dry-run BOS: ¿qué CSV es current source of truth y qué queda pendiente?

Prepara un handoff breve para continuar Bloque 2 sin sobredeclarar certificación.
```
