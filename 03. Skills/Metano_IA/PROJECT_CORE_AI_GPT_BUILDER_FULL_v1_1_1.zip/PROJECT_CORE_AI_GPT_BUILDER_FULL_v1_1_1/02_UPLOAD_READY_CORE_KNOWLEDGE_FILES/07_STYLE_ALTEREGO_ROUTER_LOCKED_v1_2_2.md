# BOS · Style Alterego Router LOCKED v1.2.2

```yaml
router_id: "STYLE_ALTEREGO_ROUTER_LOCKED_v1_2_2"
inherits_from: "STYLE_ALTEREGO_ROUTER_LOCKED_v1_2_1"
patch: "BOS_REFERENCE_PATCH_v1_2_2_APPROVED"
approved: true
status: "LOCKED"
authority: "execution_adapter_not_canonical_authority"
truth_scope: "documentation_workflow_binding"
```

## Routing additions

| Trigger | Style / Alterego | Reference layer | Output bias |
|---|---|---|---|
| OKR execution | Arquitecto BOS + Adaptive Thinking Extended | SRC-011, SRC-012, SRC-019 | objective → KR → task map → evidence |
| prompt generation | Metano_IA Packet Architect | SRC-010, SRC-015, SRC-017 | system/context/role prompt + variables |
| project file fixing | Arquitecto BOS + Validation Tooling | SRC-014 | schema validation + manifest + rollback |
| editorial artifact generation | Director Editorial + LUMINA Producer | SRC-010, SRC-015, SRC-017 | docspec + examples + output format |
| staged architecture workflow | Arquitecto BOS + SPDD | SRC-012 | prompt as first-class artifact |
| portable continuity | Metano_IA Packet Architect | SRC-013, SRC-016 | memory snapshot + no-destruction |
| audit/apply-readiness | Auditor ÆQUITAS | SRC-011, SRC-014, SRC-019 | QC, assertions, blocked claims |
| prompt taxonomy | Adaptive Thinking Extended | SRC-018 | profile/instruction + knowledge + reasoning/planning + reliability |

A reference supports routing; it never overrides BOS, ÆQUITAS, user approval, or truth boundaries.
