-- KOP-1.0 Metabase-ready schema

CREATE TABLE modules (
  module_id TEXT PRIMARY KEY,
  module_name TEXT NOT NULL,
  module_type TEXT,
  version TEXT,
  status TEXT,
  created_at TEXT,
  updated_at TEXT
);

CREATE TABLE sources (
  source_id TEXT PRIMARY KEY,
  module_id TEXT,
  source_type TEXT,
  source_name TEXT,
  path TEXT,
  authority_level TEXT,
  sha256 TEXT,
  status TEXT,
  FOREIGN KEY (module_id) REFERENCES modules(module_id)
);

CREATE TABLE turns (
  turn_id TEXT PRIMARY KEY,
  source_id TEXT,
  role TEXT,
  timestamp TEXT,
  prompt_type TEXT,
  summary TEXT,
  FOREIGN KEY (source_id) REFERENCES sources(source_id)
);

CREATE TABLE knowledge_units (
  ku_id TEXT PRIMARY KEY,
  module_id TEXT,
  title TEXT,
  claim_type TEXT,
  content TEXT,
  confidence TEXT,
  evidence_status TEXT,
  promotion_status TEXT,
  source_refs TEXT,
  tags TEXT,
  FOREIGN KEY (module_id) REFERENCES modules(module_id)
);

CREATE TABLE entities (
  entity_id TEXT PRIMARY KEY,
  module_id TEXT,
  name TEXT,
  entity_type TEXT,
  aliases TEXT,
  source_refs TEXT,
  FOREIGN KEY (module_id) REFERENCES modules(module_id)
);

CREATE TABLE relationships (
  relationship_id TEXT PRIMARY KEY,
  module_id TEXT,
  source_entity_id TEXT,
  target_entity_id TEXT,
  relationship_type TEXT,
  evidence_status TEXT,
  source_refs TEXT,
  FOREIGN KEY (module_id) REFERENCES modules(module_id)
);

CREATE TABLE artifacts (
  artifact_id TEXT PRIMARY KEY,
  module_id TEXT,
  artifact_type TEXT,
  name TEXT,
  path TEXT,
  version TEXT,
  status TEXT,
  sha256 TEXT,
  derived_from TEXT,
  FOREIGN KEY (module_id) REFERENCES modules(module_id)
);
