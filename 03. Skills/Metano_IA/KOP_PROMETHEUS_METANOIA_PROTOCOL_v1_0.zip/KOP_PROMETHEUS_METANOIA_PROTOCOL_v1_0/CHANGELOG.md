# CHANGELOG

## v1.0 · 2026-06-23

- Created KOP-1.0 protocol.
- Added PROMETHEUS-compatible verification discipline.
- Added METANO_IA-compatible multi-AI collaboration layer.
- Added Source of Truth Freezer skill spec.
- Added Delegated Knowledge Orchestrator engine prompt.
- Added JSON schema and Metabase-ready SQL schema.
- Added one-shot shell skeleton.
