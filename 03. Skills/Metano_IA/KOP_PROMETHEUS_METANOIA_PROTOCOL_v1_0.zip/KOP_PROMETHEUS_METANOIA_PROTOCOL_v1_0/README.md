# KOP_PROMETHEUS_METANOIA_PROTOCOL_v1_0

Portable bundle for a neutral, reusable knowledge-orchestration protocol derived from the user's chat-export-to-knowledge-base concept.

## Main files

- `KOP_1_0_PROTOCOL.md` — protocol specification.
- `skills/skill_source_of_truth_freezer.yaml` — skill contract.
- `engines/engine_delegated_knowledge_orchestrator.md` — engine prompt.
- `schemas/kop_manifest.schema.json` — manifest schema.
- `sql/metabase_schema.sql` — Metabase-ready relational schema.
- `ops/kop_one_shot.sh` — shell skeleton for one-shot execution.
- `evidence/ART.CONV.001_conversation_freeze_rawlog_v1.md` — copied source evidence when available.

## Status

Draft operational v1.0. Not final canon until tested against a real full source package and QA report.
