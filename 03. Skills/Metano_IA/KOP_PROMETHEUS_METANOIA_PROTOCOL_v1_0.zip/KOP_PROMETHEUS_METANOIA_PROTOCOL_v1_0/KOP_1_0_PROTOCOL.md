# KOP-1.0 · Knowledge Orchestration & Preservation Protocol

**Nombre operativo:** KOP-1.0  
**Nombre largo:** Knowledge Orchestration & Preservation Protocol  
**Nombre humano ES:** Protocolo de Orquestación y Preservación de Conocimiento  
**Compatibilidad conceptual:** PROMETHEUS · METANO_IA · KPS · TKS  
**Rol delegado:** Director / Orquestador de Conocimiento delegado por el usuario  
**Estado:** Draft operativo v1.0  
**Fecha de corte:** 2026-06-23

---

## 1. Propósito

Transformar exports de chat, lienzos, documentos, archivos, prompts, código, imágenes y decisiones en módulos de conocimiento persistentes, versionados, auditables, rehidratables y desacoplados de la conversación original.

El protocolo no preserva “un chat” como fin. Preserva la capacidad de reconstruir conocimiento útil sin depender del chat.

---

## 2. Axioma central

```text
Conversation is evidence, not canon.
Freeze is custody, not knowledge.
Knowledge Units are the first reusable asset.
Graph, RAG and BI are views generated from governed knowledge.
```

En español:

```text
La conversación es evidencia, no canon.
El freeze es custodia, no conocimiento.
Las Knowledge Units son el primer activo reutilizable.
Graph, RAG y BI son vistas generadas desde conocimiento gobernado.
```

---

## 3. Roles

### 3.1 User Owner

Dueña del criterio, intención, prioridad y aprobación final.

### 3.2 Delegated Knowledge Orchestrator

Rol asumido por la IA cuando el usuario delega 100% la normalización.

Responsabilidades:

- Recuperar contexto accesible.
- Marcar UNKNOWN cuando falte evidencia.
- Separar fuente, interpretación, decisión y output.
- Evitar canon inventado.
- Producir paquete usable, no solo explicar arquitectura.
- Mantener arquitectura en segundo plano y entregar un siguiente activo útil.

### 3.3 Prometheus Discipline

Disciplina de trazabilidad, verificación, cuarentena y límites de verdad.

Responsabilidades:

- Exigir evidencia antes de declaración.
- Firmar checksums.
- Declarar autoridad de fuentes.
- Separar raw evidence de derived knowledge.
- Bloquear final lock si faltan manifest, inventory o QA.

### 3.4 METANO_IA Collaboration Layer

Capa de colaboración multi-IA y adaptación entre asistentes, modelos y motores.

Responsabilidades:

- Permitir handoffs portables.
- Preservar reglas mínimas de contexto.
- Convertir outputs de IA en peer deltas hasta que sean promovidos por evidencia.

---

## 4. Stack de trascendencia: TKS

```yaml
tks_levels:
  T0_chat_only:
    meaning: "Conocimiento atrapado en conversación. No reusable."
  T1_snapshot:
    meaning: "Raw log, export, PDF, markdown, canvas freeze. Evidencia preservada."
  T2_knowledge_module:
    meaning: "Knowledge Units, module registry, manifest, inventory. Reusable."
  T3_knowledge_graph:
    meaning: "Entities, relationships, taxonomy, graph JSON. Navegable."
  T4_enterprise_memory:
    meaning: "RAG, database, BI seeds, Metabase-ready, reusable across tools."
```

Objetivo mínimo antes de borrar un chat: **T2**.  
Objetivo ideal para base de conocimiento: **T4**.

---

## 5. Capas de arquitectura

```text
L0 Conversation Layer
  ChatGPT · Claude · Gemini · Email · WhatsApp · Meetings · Docs
  ↓
L1 Capture Layer
  Conversation Freeze · Canvas Freeze · Asset Freeze
  ↓
L2 Knowledge Layer
  Knowledge Units · Module Registry · ADR · Changelog
  ↓
L3 Semantic Layer
  Entities · Relationships · Taxonomy · RAG chunks · Embeddings metadata
  ↓
L4 Analytics Layer
  SQL seeds · CSV tables · Metabase-ready schema
  ↓
L5 Governance Layer
  Manifest · Inventory · Checksums · QA · Final lock
```

---

## 6. Source authority ladder

```yaml
source_authority:
  A0_native_source:
    examples: ["original files", "native exports", "uploaded raw logs", "official datasets"]
    authority: highest
  A1_freeze_snapshot:
    examples: ["conversation freeze", "canvas freeze", "exported markdown"]
    authority: high
  A2_derived_structured:
    examples: ["knowledge_units", "registries", "graphs", "csv seeds"]
    authority: medium_high
  A3_generated_view:
    examples: ["PDF", "PPTX", "infographic", "HTML visual shell"]
    authority: medium
  A4_ai_interpretation:
    examples: ["assistant synthesis", "unverified summary", "hypothesis"]
    authority: provisional
```

Rule:

```text
Lower layer regenerates upper layer.
Upper layer never overrides lower layer.
```

---

## 7. Memory per turns stacking

No se guarda todo el chat como memoria permanente. Se transforma por turnos:

```text
Turn
→ Observation
→ Insight
→ Knowledge Unit
→ Module
→ Entity / Relationship
→ RAG Chunk
→ Analytics Row
```

Schema mínimo:

```yaml
turn_stack_item:
  turn_id: T0001
  timestamp: "YYYY-MM-DDTHH:mm:ss"
  role: user|assistant|system|tool
  source_ref: ART.CONV.001
  observation: "Qué se dijo explícitamente"
  insight: "Qué conocimiento reusable emerge"
  ku_id: KU.DOMAIN.TOPIC.001
  module_id: KG.DOMAIN.SUBDOMAIN.001
  confidence: high|medium|low
  evidence_status: explicit|inferred|unknown
  promotion_status: raw|candidate|approved|locked
```

---

## 8. Knowledge Unit standard

```yaml
knowledge_unit:
  ku_id: KU.MKT.BRAND.001
  module_id: KG.MKT.BRAND.001
  title: "Análisis y Estrategias de Marca"
  claim_type: observation|decision|framework|method|output|risk
  content: "Contenido reusable, breve, auditable."
  source_refs:
    - ART.CONV.001#T0001
  entities:
    - Natura
    - Oriflame
  tags:
    - marketing-research
    - competitive-analysis
  confidence: high
  status: candidate
  created_at: "2026-06-23"
```

---

## 9. Progressive hydration order

```yaml
hydration_order:
  H0_manifest:
    load:
      - manifest.json
      - checksums.sha256
  H1_orientation:
    load:
      - README.md
      - CHANGELOG.md
      - ADR/
  H2_evidence:
    load:
      - evidence/
      - raw_logs/
      - canvas_versions/
  H3_knowledge:
    load:
      - knowledge_units.jsonl
      - module_registry.csv
      - source_registry.csv
  H4_semantic:
    load:
      - entities.csv
      - relationships.csv
      - knowledge_graph.json
      - taxonomy.yaml
  H5_activation:
    load:
      - rag_chunks/
      - metabase_seed/
      - engine_prompts/
      - skills/
```

Minimum boot prompt:

```text
Rehydrate using manifest.json first. Treat evidence as source, Knowledge Units as reusable knowledge, Graph/RAG/BI as generated views. Mark UNKNOWN instead of inventing. Do not declare final canon without inventory + checksums + QA.
```

---

## 10. Critical Success Factors

```yaml
csf:
  CSF_001_preservation:
    target: "Knowledge survives chat deletion"
  CSF_002_independence:
    target: "Module understandable without original ChatGPT thread"
  CSF_003_traceability:
    target: "Every approved claim maps to at least one source ref"
  CSF_004_reusability:
    target: "Module feeds RAG, Notion, GitHub, Obsidian, Metabase or agent systems"
  CSF_005_governance:
    target: "No final lock without manifest, inventory, checksums and QA"
```

---

## 11. OKR / KPI / Targets

```yaml
okr:
  objective: "Create a reusable, governed knowledge module from conversational evidence"
  key_results:
    KR1:
      metric: "accessible_evidence_registered"
      target: "100%"
    KR2:
      metric: "approved_knowledge_units_with_source_refs"
      target: "100%"
    KR3:
      metric: "files_with_sha256"
      target: "100%"
    KR4:
      metric: "module_rehydratable_without_chat"
      target: "PASS"
    KR5:
      metric: "metabase_ready_tables_generated"
      target: "modules, sources, knowledge_units, entities, relationships, artifacts"
```

---

## 12. One-shot execution sequence

```text
01 intake_source
02 normalize_raw_log
03 assign_turn_ids
04 register_sources
05 extract_turn_stack
06 generate_knowledge_units
07 build_module_registry
08 build_entity_registry
09 build_relationship_registry
10 build_knowledge_graph
11 generate_rag_chunks
12 generate_metabase_seed
13 generate_manifest
14 generate_inventory
15 generate_checksums
16 run_qa
17 declare_freeze_status
18 export_bundle
```

Command skeleton:

```bash
python tools/kop_build.py \
  --input "evidence/ART.CONV.001_conversation_freeze_rawlog_v1.md" \
  --module-id "KG.MKT.BRAND.001" \
  --module-name "Análisis y Estrategias de Marca" \
  --standard "KOP-1.0" \
  --out "dist/KG.MKT.BRAND.001_KOP_FREEZE_v1_0"
```

---

## 13. Lock policy

```yaml
lock_policy:
  raw_evidence:
    mutable: false
    modification: "copy forward only"
  derived_registries:
    mutable: true
    modification: "new version with changelog"
  generated_views:
    mutable: true
    modification: "regenerate from lower layers"
  final_canon:
    allowed_when:
      - manifest_exists
      - inventory_exists
      - checksums_exist
      - source_registry_exists
      - qa_report_passed
      - unknowns_isolated
```

---

## 14. Invocation phrase

Use this to activate the protocol in another chat or engine:

```text
Actúa como Delegated Knowledge Orchestrator under KOP-1.0. Convert the provided export/log/files into a governed, rehydratable knowledge module. Evidence before assertion. Raw evidence is source, not canon. Extract turn stacks, Knowledge Units, registries, graph, RAG chunks, Metabase seed, manifest, inventory and SHA-256. Mark UNKNOWN instead of inventing. Do not final-lock without QA.
```

Spanish version:

```text
Actúa como Orquestador Delegado de Conocimiento bajo KOP-1.0. Convierte el export/log/archivos proporcionados en un módulo de conocimiento gobernado y rehidratable. Evidencia antes de afirmación. La evidencia raw es fuente, no canon. Extrae turn stacks, Knowledge Units, registros, grafo, chunks RAG, seed Metabase, manifest, inventario y SHA-256. Marca UNKNOWN en vez de inventar. No declares final lock sin QA.
```
