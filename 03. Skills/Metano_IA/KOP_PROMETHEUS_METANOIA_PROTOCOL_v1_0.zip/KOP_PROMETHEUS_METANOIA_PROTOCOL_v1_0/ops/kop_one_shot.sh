#!/usr/bin/env bash
set -euo pipefail

INPUT="${1:-evidence/ART.CONV.001_conversation_freeze_rawlog_v1.md}"
MODULE_ID="${2:-KG.MKT.BRAND.001}"
MODULE_NAME="${3:-Análisis y Estrategias de Marca}"
OUT="${4:-dist/${MODULE_ID}_KOP_FREEZE_v1_0}"

echo "KOP-1.0 one-shot sequence"
echo "Input: $INPUT"
echo "Module: $MODULE_ID · $MODULE_NAME"
echo "Output: $OUT"

mkdir -p "$OUT"/{evidence,registry,knowledge_units,graph,rag_chunks,metabase_seed,qa}
cp "$INPUT" "$OUT/evidence/" 2>/dev/null || true

cat > "$OUT/README.md" <<EOF
# $MODULE_ID · $MODULE_NAME

Generated under KOP-1.0.

Hydration order:
1. manifest.json
2. README.md / CHANGELOG.md / ADR
3. evidence/
4. knowledge_units/
5. graph/
6. rag_chunks/
7. metabase_seed/
EOF

cat > "$OUT/manifest.json" <<EOF
{
  "standard": "KOP-1.0",
  "module": {
    "module_id": "$MODULE_ID",
    "module_name": "$MODULE_NAME",
    "status": "candidate"
  },
  "lock_status": "not_final_locked",
  "required_next": ["turn_stack", "knowledge_units", "registries", "graph", "qa"]
}
EOF

find "$OUT" -type f ! -name checksums.sha256 -print0 | sort -z | xargs -0 shasum -a 256 > "$OUT/checksums.sha256"
echo "Created candidate package at $OUT"
